"""Deck renderer: validated deck spec -> PPTX in the IOTA theme (six colors, chevron mark)."""
import re
import tempfile
from pathlib import Path

from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.oxml.ns import qn
from pptx.util import Inches, Pt, Emu

import iota_theme as T
from renderers import chart as chart_r

W, H = Inches(13.333), Inches(7.5)
ML = Inches(0.7)
CW = W - 2 * ML
RGB = T.pptx_rgb
NUM = re.compile(r"[-+]?[0-9][0-9.,]*%?")


def _rect(sl, x, y, w, h, fill):
    s = sl.shapes.add_shape(MSO_SHAPE.RECTANGLE, x, y, w, h)
    s.fill.solid()
    s.fill.fore_color.rgb = RGB(fill)
    s.line.fill.background()
    s.shadow.inherit = False
    return s


def _text(sl, x, y, w, h, paras, size, color, bold=False, align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP,
          bullets=False, space=6):
    tb = sl.shapes.add_textbox(x, y, w, h)
    tf = tb.text_frame
    tf.word_wrap = True
    tf.vertical_anchor = anchor
    tf.margin_left = tf.margin_right = Inches(0.05)
    for i, line in enumerate(paras if isinstance(paras, list) else [paras]):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = align
        p.space_after = Pt(space)
        if bullets:
            r0 = p.add_run()
            r0.text = "\u25AA  "
            _font(r0, size, T.STEEL)
        r = p.add_run()
        r.text = T.clean(line)
        _font(r, size, color, bold)
    return tb


def _font(run, size, color, bold=False):
    f = run.font
    f.name = T.FONT_NAME
    f.size = Pt(size)
    f.bold = bold
    f.italic = False
    f.color.rgb = RGB(color)


def _base(prs, title, idx, total, footer):
    sl = prs.slides.add_slide(prs.slide_layouts[6])
    sl.background.fill.solid()
    sl.background.fill.fore_color.rgb = RGB(T.BLACK)
    _text(sl, ML, Inches(0.45), CW - Inches(1), Inches(0.8), title, 30, T.CHROME, bold=True)
    _rect(sl, ML, Inches(1.25), Inches(0.9), Emu(28000), T.SILVER)
    if T.mark_path("charcoal").exists():
        sl.shapes.add_picture(str(T.mark_path("charcoal")), W - ML - Inches(0.42), Inches(0.5), Inches(0.42), Inches(0.42))
    _rect(sl, ML, Inches(6.92), CW, Emu(9525), T.NEAR)
    _text(sl, ML, Inches(6.98), Inches(8), Inches(0.35), footer, 11, T.STEEL)
    _text(sl, W - ML - Inches(2), Inches(6.98), Inches(2), Inches(0.35), f"{idx} / {total}", 11, T.STEEL,
          align=PP_ALIGN.RIGHT)
    return sl


def _table(sl, x, y, w, cols, rows, widths):
    nr, nc = len(rows) + 1, len(cols)
    rh = Inches(0.46) if nr <= 10 else Inches(0.34)
    size = 14 if nr <= 10 else 12
    gt = sl.shapes.add_table(nr, nc, x, y, w, rh * nr)
    tbl = gt.table
    tblPr = gt._element.graphic.graphicData.tbl.tblPr
    tblPr.set("bandRow", "0")
    tblPr.set("firstRow", "0")
    sid = tblPr.find(qn("a:tableStyleId"))
    if sid is not None:
        sid.text = "{2D5ABB26-0587-4C30-8999-92F81FD0307C}"  # built-in "No Style, No Grid"
    if widths:
        for i, cw in enumerate(widths):
            tbl.columns[i].width = int(w * cw)
    numeric = [bool(rows) and all(NUM.fullmatch(str(r[c]).strip() or "x") for r in rows) for c in range(nc)]
    for r in range(nr):
        tbl.rows[r].height = rh
        for c in range(nc):
            cell = tbl.cell(r, c)
            val = cols[c] if r == 0 else rows[r - 1][c]
            cell.fill.solid()
            cell.fill.fore_color.rgb = RGB(T.NEAR if r == 0 else T.BLACK)
            cell.margin_left = Inches(0.12)
            cell.vertical_anchor = MSO_ANCHOR.MIDDLE
            p = cell.text_frame.paragraphs[0]
            p.text = ""
            run = p.add_run()
            run.text = T.clean(val)
            p.alignment = PP_ALIGN.RIGHT if numeric[c] else PP_ALIGN.LEFT
            _font(run, size if r else size - 1, T.HIGHLIGHT if r == 0 else (T.CHROME if c == 0 else T.SILVER), bold=(r == 0))
            tcPr = cell._tc.get_or_add_tcPr()
            for tag in ("a:lnL", "a:lnR", "a:lnT"):
                ln = tcPr.makeelement(qn(tag), {"w": "0"})
                ln.append(ln.makeelement(qn("a:noFill"), {}))
                tcPr.append(ln)
            lnB = tcPr.makeelement(qn("a:lnB"), {"w": "9525"})
            sf = lnB.makeelement(qn("a:solidFill"), {})
            sf.append(sf.makeelement(qn("a:srgbClr"), {"val": (T.STEEL if r == 0 else T.NEAR).lstrip("#")}))
            lnB.append(sf)
            tcPr.append(lnB)
    return gt


def render(spec, out_path, style="charcoal"):
    # Decks are always the charcoal theme (approved sample). style kept for a uniform signature.
    prs = Presentation()
    prs.slide_width, prs.slide_height = W, H
    slides = spec["slides"]
    n = len(slides)
    footer = spec.get("footer") or f"IOTA  |  {spec['title']}"
    with tempfile.TemporaryDirectory(prefix="iota-deck-") as tmp:
        for i, s in enumerate(slides, 1):
            k = s["layout"]
            if k == "title":
                sl = prs.slides.add_slide(prs.slide_layouts[6])
                sl.background.fill.solid()
                sl.background.fill.fore_color.rgb = RGB(T.BLACK)
                _rect(sl, 0, 0, Inches(4.6), H, T.NEAR)
                if T.mark_path("charcoal").exists():
                    sl.shapes.add_picture(str(T.mark_path("charcoal")), Inches(0.9), Inches(2.35), Inches(2.8), Inches(2.8))
                _text(sl, Inches(5.3), Inches(2.3), Inches(7.3), Inches(1.6), s["title"], 44, T.CHROME, bold=True,
                      anchor=MSO_ANCHOR.BOTTOM)
                _rect(sl, Inches(5.35), Inches(4.05), Inches(1.1), Emu(28000), T.SILVER)
                _text(sl, Inches(5.3), Inches(4.25), Inches(7.3), Inches(1.0), s.get("subtitle", ""), 20, T.SILVER)
                _text(sl, Inches(5.3), Inches(6.6), Inches(7.3), Inches(0.4), s.get("meta", ""), 12, T.STEEL)
            elif k == "bullets":
                sl = _base(prs, s["title"], i, n, footer)
                note = s.get("note")
                bw = CW * 0.62 if note else CW
                _text(sl, ML, Inches(1.6), bw, Inches(5), s["bullets"], 20, T.HIGHLIGHT, bullets=True, space=14)
                if note:
                    nx = ML + CW * 0.67
                    nw = CW * 0.33
                    _rect(sl, nx, Inches(1.6), nw, Inches(4.9), T.NEAR)
                    _text(sl, nx + Inches(0.3), Inches(1.85), nw - Inches(0.6), Inches(0.4), note.get("label", ""), 13,
                          T.SILVER, bold=True)
                    _text(sl, nx + Inches(0.3), Inches(2.35), nw - Inches(0.6), Inches(4), note["lines"], 15,
                          T.HIGHLIGHT, space=10)
            elif k == "chart":
                sl = _base(prs, s["title"], i, n, footer)
                png = Path(tmp) / f"slide{i}.png"
                chart_r.render(s["chart"], png, "charcoal", size=(11.9, 5.0), mark=False, show_titles=False)
                sl.shapes.add_picture(str(png), ML, Inches(1.55), CW, int(CW * 5.0 / 11.9))
                if s.get("caption"):
                    _text(sl, ML, Inches(6.5), CW, Inches(0.35), s["caption"], 12, T.SILVER)
            elif k == "table":
                sl = _base(prs, s["title"], i, n, footer)
                _table(sl, ML, Inches(1.65), CW, s["columns"], s["rows"], s.get("col_widths"))
                if s.get("caption"):
                    _text(sl, ML, Inches(6.45), CW, Inches(0.35), s["caption"], 12, T.SILVER)
            elif k == "two_column":
                sl = _base(prs, s["title"], i, n, footer)
                gap = Inches(0.4)
                cw = int((CW - gap) / 2)
                for j, col in enumerate(s["columns"]):
                    x = ML + j * (cw + gap)
                    _rect(sl, x, Inches(1.6), cw, Inches(4.95), T.NEAR)
                    _rect(sl, x, Inches(1.6), cw, Emu(28000), T.SILVER if j == 0 else T.STEEL)
                    _text(sl, x + Inches(0.3), Inches(1.85), cw - Inches(0.6), Inches(0.5), col["heading"], 20,
                          T.CHROME, bold=True)
                    _text(sl, x + Inches(0.3), Inches(2.5), cw - Inches(0.6), Inches(3.9), col["bullets"], 16,
                          T.HIGHLIGHT, bullets=True, space=10)
        prs.core_properties.title = spec["title"]
        prs.core_properties.author = "IOTA"
        prs.save(str(out_path))
    return out_path
