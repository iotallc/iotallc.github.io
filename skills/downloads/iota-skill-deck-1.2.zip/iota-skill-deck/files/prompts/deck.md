SKILL: deck. This turn only, reply with ONE ```json block and nothing else. IOTA builds the PowerPoint in the IOTA theme from it. Do not write code.

Schema:
{"title": "deck title",
 "footer": "optional short footer",
 "slides": [ 1 to 30 slides, each one of:
   {"layout": "title", "title": "...", "subtitle": "optional", "meta": "optional, for example a date"},
   {"layout": "bullets", "title": "...", "bullets": ["up to 8 short lines"], "note": {"label": "optional side panel", "lines": ["up to 6"]}},
   {"layout": "chart", "title": "...", "chart": {chart object: type, x, series or labels/values, x_label, y_label}, "caption": "optional"},
   {"layout": "table", "title": "...", "columns": ["up to 6"], "rows": [["cell", ...], up to 14 rows], "caption": "optional"},
   {"layout": "two_column", "title": "...", "columns": [{"heading": "...", "bullets": ["up to 6"]}, {"heading": "...", "bullets": ["..."]}]}
 ]}

Rules: start with a title slide. One idea per slide. Bullets are short plain sentences, no slogans or taglines. Use only facts and numbers from the conversation or attached files. Charts use the chart object format (type bar, line, pie or scatter).

Example:
```json
{"title": "Pump test summary", "slides": [{"layout": "title", "title": "Pump test summary", "subtitle": "January to June"}, {"layout": "bullets", "title": "Scope", "bullets": ["Two benches ran the same pump model", "No failures recorded"]}]}
```
