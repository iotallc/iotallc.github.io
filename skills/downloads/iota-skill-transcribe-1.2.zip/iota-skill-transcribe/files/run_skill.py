"""IOTA skill runner.

Usage (IOTA calls this; the model never writes rendering code):
  python run_skill.py --skill chart --spec spec.json [--out-dir DIR] [--style charcoal|print] [--name NAME]
  python run_skill.py --skill units|fin --spec spec.json [--out-dir DIR] [--opt chart=1]
  python run_skill.py --skill ocr --input FILE [--input FILE] [--opt searchable=1] [--progress-file P]
  python run_skill.py --skill transcribe --input FILE [--opt model=tiny] [--progress-file P]
  python run_skill.py --skill notes --spec reply.json --opt transcript=<transcript .md>
  python run_skill.py --skill chart --spec spec.json --validate-only
  python run_skill.py --prompt chart        (prints the per-turn instruction card)
  python run_skill.py --check               (library check)
  python run_skill.py --peek data.csv        (column names and first rows of a CSV or XLSX)
  python run_skill.py --list

Always prints exactly one JSON object on stdout:
  {"ok": true, "skill": ..., "file": ..., "spec_file": ..., "warnings": [...], "ms": ...}
  (units, fin, ocr, transcribe and notes also return "text" (markdown for the chat) and "files": [...])
  {"ok": false, "skill": ..., "stage": "input|validate|render", "error": ..., "errors": [...]}
Exit code 0 on success, 2 on spec errors, 3 on render errors, 4 on missing libraries.
"""
import argparse
import datetime as dt
import importlib
import json
import sys
import time
import traceback
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import iota_theme as T  # noqa: E402
import spec_check  # noqa: E402

SKILLS = {
    "chart": dict(ext=".png", label="Chart", needs=["matplotlib", "numpy", "PIL"]),
    "deck": dict(ext=".pptx", label="Deck", needs=["pptx", "matplotlib", "PIL"]),
    "pdf": dict(ext=".pdf", label="PDF", needs=["reportlab", "matplotlib", "PIL"]),
    "units": dict(ext="", label="Units", kind="text", needs=["pint"]),
    "fin": dict(ext=".xlsx", label="Finance", kind="text", needs=["xlsxwriter", "matplotlib"]),
    "ocr": dict(ext=".txt", label="OCR", kind="direct", needs=["rapidocr_onnxruntime", "onnxruntime", "cv2", "pypdfium2", "pdfplumber", "PIL", "numpy"]),
    "transcribe": dict(ext=".md", label="Transcript", kind="direct", needs=["av"]),
    "notes": dict(ext=".md", label="Meeting notes", kind="notes", needs=[]),
}
LIBS = ["pptx", "matplotlib", "numpy", "PIL", "reportlab", "openpyxl", "pdfplumber", "pypdf", "docx", "lxml",
        "xlsxwriter", "pint", "pypdfium2", "rapidocr_onnxruntime", "onnxruntime", "cv2", "av"]
TEXT_CAP = 100000


def emit(obj, code=0):
    sys.stdout.write(json.dumps(obj, ensure_ascii=False) + "\n")
    sys.stdout.flush()
    sys.exit(code)


def check_libs(names):
    missing, versions = [], {}
    for n in names:
        try:
            m = importlib.import_module(n)
            versions[n] = getattr(m, "__version__", getattr(m, "VERSION", "ok"))
        except Exception as e:  # noqa: BLE001
            missing.append(f"{n} ({type(e).__name__})")
    return missing, versions


def extract_json(text):
    """Pull one JSON object from model text (a ```json fence or the first {...} block)."""
    import re
    m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.S)
    raw = m.group(1) if m else None
    if raw is None:
        start = text.find("{")
        end = text.rfind("}")
        if start < 0 or end <= start:
            raise ValueError("No JSON object found in the reply.")
        raw = text[start:end + 1]
    return json.loads(raw)


def unique_path(folder, stem, ext):
    p = folder / f"{stem}{ext}"
    n = 2
    while p.exists():
        p = folder / f"{stem}-{n}{ext}"
        n += 1
    return p


class Progress:
    """Writes {"pct", "msg", "t"} to a small JSON file that IOTA polls. Throttled."""

    def __init__(self, path):
        self.path = Path(path) if path else None
        self.last = 0.0
        self.msg = ""

    def __call__(self, i, n, msg="", force=False):
        if not self.path:
            return
        now = time.time()
        if not force and now - self.last < 0.25 and msg == self.msg:
            return
        self.last, self.msg = now, msg
        pct = int(max(0, min(100, (100.0 * i / n) if n else 0)))
        try:
            tmp = self.path.with_name(self.path.name + ".tmp")
            tmp.write_text(json.dumps({"pct": pct, "msg": msg, "t": now}), encoding="utf-8")
            import os
            os.replace(tmp, self.path)
        except OSError:
            pass


def parse_opts(items):
    out = {}
    for it in items or []:
        if "=" in it:
            k, v = it.split("=", 1)
            out[k.strip().lower()] = v.strip()
        elif it.strip():
            out[it.strip().lower()] = "1"
    return out


def load_spec(path, skill):
    try:
        raw = Path(path).read_text(encoding="utf-8-sig")
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return extract_json(raw)
    except Exception as e:  # noqa: BLE001
        emit({"ok": False, "skill": skill, "stage": "input", "error": f"Spec is not valid JSON: {e}",
              "errors": [f"Spec is not valid JSON: {e}"]}, 2)


def cap_text(t):
    t = t or ""
    if len(t) > TEXT_CAP:
        return t[:TEXT_CAP] + "\n\n[Text cut at 100,000 characters for the chat. The saved file has all of it.]", True
    return t, False


def run_text_skill(a, skill, meta, opts):
    """units and fin: spec -> deterministic compute -> markdown text (+ xlsx/png for fin)."""
    t0 = time.time()
    spec = load_spec(a.spec, skill)
    mod = importlib.import_module(f"tools.{skill}")
    ctx = spec_check.Ctx()
    try:
        norm = mod.check(spec, ctx)
    except Exception as e:  # noqa: BLE001
        ctx.err(f"Spec could not be read: {e}")
        norm = {}
    if ctx.errors:
        emit({"ok": False, "skill": skill, "stage": "validate", "error": f"{meta['label']} not done: {ctx.errors[0]}",
              "errors": ctx.errors, "warnings": ctx.warnings}, 2)
    if a.validate_only:
        emit({"ok": True, "skill": skill, "stage": "validate", "warnings": ctx.warnings, "spec": norm})
    missing, _ = check_libs(meta["needs"])
    if missing:
        emit({"ok": False, "skill": skill, "stage": "render",
              "error": f"{meta['label']} not done: missing Python libraries: {', '.join(missing)}. Rail > Skills > Check libraries.",
              "errors": missing}, 4)
    try:
        res = mod.compute(norm)
    except Exception as e:  # noqa: BLE001
        emit({"ok": False, "skill": skill, "stage": "render", "error": f"{meta['label']} not done: {e}",
              "errors": [str(e)], "trace": traceback.format_exc(limit=3)}, 3)
    if res["errors"] and not res["results"]:
        emit({"ok": False, "skill": skill, "stage": "validate", "error": f"{meta['label']} not done: {res['errors'][0]}",
              "errors": res["errors"], "warnings": ctx.warnings + res["warnings"]}, 2)
    files = []
    if skill == "fin" and res.get("tables"):
        out_dir = Path(a.out_dir) if a.out_dir else T.OUTPUT / "fin"
        try:
            out_dir.mkdir(parents=True, exist_ok=True)
            want_chart = bool(norm.get("chart")) or str(opts.get("chart", "0")) in ("1", "true", "yes")
            for t in res["tables"]:
                stem = f"{dt.datetime.now():%Y-%m-%d_%H%M}_{T.slug(t['title'] or t['kind'])}"
                xl = unique_path(out_dir, stem, ".xlsx")
                png = None
                if want_chart:
                    png = xl.with_suffix(".png")
                    mod.chart_png(t, png, opts.get("style", "charcoal") if opts.get("style") in T.STYLES else "charcoal")
                if t["kind"] == "amortization":
                    mod.write_amortization_xlsx(t, xl, png)
                else:
                    mod.write_dcf_xlsx(t, xl, png)
                files.append(str(xl))
                if png:
                    files.append(str(png))
        except Exception as e:  # noqa: BLE001
            res["warnings"].append(f"The table file was not written: {e}")
    text, cut = cap_text(res["text"])
    emit({"ok": True, "skill": skill, "label": meta["label"], "text": text, "files": files,
          "file": files[0] if files else "", "bytes": sum(Path(f).stat().st_size for f in files),
          "results": res["results"], "warnings": ctx.warnings + res["warnings"], "item_errors": res["errors"],
          "ms": int((time.time() - t0) * 1000)})


def run_direct_skill(a, skill, meta, opts):
    """ocr and transcribe: input files -> text and files. No model."""
    t0 = time.time()
    missing, _ = check_libs(meta["needs"])
    if missing:
        emit({"ok": False, "skill": skill, "stage": "render",
              "error": f"{meta['label']} not done: missing Python libraries: {', '.join(missing)}. Rail > Skills > Check libraries.",
              "errors": missing}, 4)
    prog = Progress(a.progress_file)
    out_dir = Path(a.out_dir) if a.out_dir else T.OUTPUT / skill
    tmp_dir = Path(a.tmp_dir) if a.tmp_dir else T.OUTPUT / "tmp"
    mod = importlib.import_module(f"tools.{skill}")
    try:
        res = mod.run(a.input or [], opts, out_dir, tmp_dir, prog)
    except (ValueError, FileNotFoundError) as e:
        emit({"ok": False, "skill": skill, "stage": "input", "error": f"{meta['label']} not done: {e}", "errors": [str(e)]}, 2)
    except Exception as e:  # noqa: BLE001
        emit({"ok": False, "skill": skill, "stage": "render", "error": f"{meta['label']} not done: {e}",
              "errors": [str(e)], "trace": traceback.format_exc(limit=4)}, 3)
    prog(1, 1, "done", force=True)
    text, cut = cap_text(res.get("text", ""))
    files = [f for f in res.get("files", []) if f]
    out = {"ok": True, "skill": skill, "label": meta["label"], "text": text, "text_cut": cut, "files": files,
           "file": files[0] if files else "", "bytes": sum(Path(f).stat().st_size for f in files if Path(f).is_file()),
           "warnings": res.get("warnings", []), "meta": res.get("meta", {}), "ms": int((time.time() - t0) * 1000)}
    for k in ("txt_file", "md_file", "save_stem", "transcript_txt", "transcript_md", "chars"):
        if k in res:
            out[k] = res[k]
    emit(out)


def run_notes(a, opts):
    t0 = time.time()
    spec = load_spec(a.spec, "notes")
    from tools import notes
    ctx = spec_check.Ctx()
    norm = notes.check(spec, ctx)
    if ctx.errors:
        emit({"ok": False, "skill": "notes", "stage": "validate", "error": f"Meeting notes not made: {ctx.errors[0]}",
              "errors": ctx.errors, "warnings": ctx.warnings}, 2)
    tr = opts.get("transcript")
    if not tr or not Path(tr).is_file():
        emit({"ok": False, "skill": "notes", "stage": "input", "error": "Meeting notes not made: transcript file not found.",
              "errors": ["transcript file not found"]}, 2)
    try:
        out, text = notes.render(norm, tr)
    except Exception as e:  # noqa: BLE001
        emit({"ok": False, "skill": "notes", "stage": "render", "error": f"Meeting notes not made: {e}", "errors": [str(e)]}, 3)
    emit({"ok": True, "skill": "notes", "label": "Meeting notes", "text": text, "files": [str(out)], "file": str(out),
          "bytes": out.stat().st_size, "warnings": ctx.warnings, "ms": int((time.time() - t0) * 1000)})


def main(argv=None):
    ap = argparse.ArgumentParser(description="IOTA skill runner")
    ap.add_argument("--skill", choices=sorted(SKILLS))
    ap.add_argument("--spec", help="Spec JSON file, or a text file holding the model reply with a JSON block.")
    ap.add_argument("--out-dir", help="Default: <kit>\\output\\<skill>")
    ap.add_argument("--style", choices=T.STYLES, help="charcoal (default) or print. Overrides the spec.")
    ap.add_argument("--name", help="File name stem. Default: date_time_title")
    ap.add_argument("--validate-only", action="store_true")
    ap.add_argument("--prompt", choices=sorted(SKILLS), help="Print the instruction card for a skill.")
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--peek", action="append", help="CSV or XLSX file to describe (repeatable).")
    ap.add_argument("--input", action="append", help="Input file for ocr or transcribe (repeatable).")
    ap.add_argument("--opt", action="append", help="Skill option k=v (repeatable).")
    ap.add_argument("--progress-file", help="JSON progress file IOTA polls.")
    ap.add_argument("--tmp-dir", help="Scratch folder. Default: <kit>\\output\\tmp")
    a = ap.parse_args(argv)

    if a.list:
        emit({"ok": True, "skills": {k: {"ext": v["ext"], "label": v["label"]} for k, v in SKILLS.items()}})
    if a.check:
        missing, versions = check_libs(LIBS)
        emit({"ok": not missing, "python": sys.version.split()[0], "executable": sys.executable,
              "missing": missing, "versions": {k: str(v) for k, v in versions.items()},
              "font": str(T.font_file() or "none (fallback)"), "mark": T.mark_path().is_file()}, 0 if not missing else 4)
    if a.peek:
        files = []
        for f in a.peek:
            try:
                headers, rows = spec_check.load_table(f)
                head = [[str(c) for c in r[:len(headers)]] for r in rows[:20]]
                files.append({"file": str(Path(f).resolve()), "name": Path(f).name, "columns": headers,
                              "rows": len(rows), "first_rows": head})
            except Exception as e:  # noqa: BLE001
                files.append({"file": str(f), "name": Path(f).name, "error": str(e)})
        emit({"ok": all("error" not in x for x in files), "files": files})
    if a.prompt:
        card = HERE / "prompts" / f"{a.prompt}.md"
        emit({"ok": card.is_file(), "skill": a.prompt, "prompt": card.read_text(encoding="utf-8") if card.is_file() else ""})
    if not a.skill:
        emit({"ok": False, "stage": "input", "error": "Need --skill."}, 2)
    kind = SKILLS[a.skill].get("kind", "file")
    opts = parse_opts(a.opt)
    if kind == "direct":
        run_direct_skill(a, a.skill, SKILLS[a.skill], opts)
    if not a.spec:
        emit({"ok": False, "skill": a.skill, "stage": "input", "error": "Need --spec."}, 2)
    if kind == "text":
        run_text_skill(a, a.skill, SKILLS[a.skill], opts)
    if kind == "notes":
        run_notes(a, opts)

    skill, meta = a.skill, SKILLS[a.skill]
    t0 = time.time()
    try:
        raw = Path(a.spec).read_text(encoding="utf-8-sig")
        try:
            spec = json.loads(raw)
        except json.JSONDecodeError:
            spec = extract_json(raw)
    except Exception as e:  # noqa: BLE001
        emit({"ok": False, "skill": skill, "stage": "input", "error": f"Spec is not valid JSON: {e}",
              "errors": [f"Spec is not valid JSON: {e}"]}, 2)

    if isinstance(spec, dict) and spec.get("skill") not in (None, skill):
        pass  # tolerate a mismatched label; the runner decides the skill
    norm, ctx = spec_check.CHECKS[skill](spec)
    if ctx.errors:
        emit({"ok": False, "skill": skill, "stage": "validate",
              "error": f"{meta['label']} not made: {ctx.errors[0]}", "errors": ctx.errors, "warnings": ctx.warnings}, 2)
    if a.validate_only:
        emit({"ok": True, "skill": skill, "stage": "validate", "warnings": ctx.warnings, "spec": norm})

    missing, _ = check_libs(meta["needs"])
    if missing:
        emit({"ok": False, "skill": skill, "stage": "render",
              "error": f"{meta['label']} not made: missing Python libraries: {', '.join(missing)}. "
                       f"Rail > Skills > Check libraries.", "errors": missing}, 4)

    style = a.style or (norm.get("style") if skill == "pdf" else None) or "charcoal"
    if skill == "pdf":
        norm["style"] = style
    out_dir = Path(a.out_dir) if a.out_dir else T.OUTPUT / skill
    try:
        out_dir.mkdir(parents=True, exist_ok=True)
        stem = a.name or f"{dt.datetime.now():%Y-%m-%d_%H%M}_{T.slug(norm.get('title') or skill)}"
        stem = T.slug(stem, 80) if a.name else stem
        out = unique_path(out_dir, stem, meta["ext"])
        mod = importlib.import_module(f"renderers.{skill}")
        mod.render(norm, out, style)
        if not out.is_file() or out.stat().st_size == 0:
            raise RuntimeError("renderer wrote no file")
        spec_file = out.with_name(out.stem + ".spec.json")
        norm_out = dict(norm)
        norm_out["skill"] = skill
        spec_file.write_text(json.dumps(norm_out, indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception as e:  # noqa: BLE001
        tb = traceback.format_exc(limit=3)
        emit({"ok": False, "skill": skill, "stage": "render", "error": f"{meta['label']} not made: {e}",
              "errors": [str(e)], "trace": tb}, 3)
    emit({"ok": True, "skill": skill, "label": meta["label"], "file": str(out), "spec_file": str(spec_file),
          "bytes": out.stat().st_size, "style": style, "warnings": ctx.warnings,
          "ms": int((time.time() - t0) * 1000)})


if __name__ == "__main__":
    main()
