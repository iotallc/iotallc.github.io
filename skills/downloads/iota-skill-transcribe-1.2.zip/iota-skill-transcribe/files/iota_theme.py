"""IOTA shared theme for skills: palette, fonts, chevron mark, chart/deck/PDF styles.

Plain palette and mark only. Used by every renderer so charts, decks, PDFs and
Word files match. Paths are relative to the kit, so any drive letter works.
"""
import os
import re
import sys
from pathlib import Path

SKILLS_DIR = Path(__file__).resolve().parent
KIT = SKILLS_DIR.parent.parent  # scripts\skills -> kit root
ASSETS = KIT / "assets" / "brand"
OUTPUT = KIT / "output"

# Palette (the only six theme colors)
BLACK = "#000000"
NEAR = "#141414"
STEEL = "#606060"
SILVER = "#929294"
HIGHLIGHT = "#CBCBCB"
CHROME = "#E0E0E0"
PALETTE = (BLACK, NEAR, STEEL, SILVER, HIGHLIGHT, CHROME)
WHITE = "#FFFFFF"  # print style page only

STYLES = ("charcoal", "print")

# Per-style roles. Charcoal = default. Print = white pages, black text.
ROLES = {
    "charcoal": dict(page=NEAR, field=BLACK, panel=BLACK, title=CHROME, heading=CHROME, text=HIGHLIGHT,
                     body=SILVER, muted=STEEL, rule=STEEL, faint=BLACK, header_fill=BLACK, header_text=HIGHLIGHT,
                     grid=BLACK, axes_face=BLACK, axes_edge=STEEL,
                     series=(CHROME, SILVER, STEEL, HIGHLIGHT), pie=(CHROME, HIGHLIGHT, SILVER, STEEL, NEAR),
                     mark="iota-mark.png"),
    "print": dict(page=WHITE, field=WHITE, panel=WHITE, title=BLACK, heading=BLACK, text=BLACK,
                  body=NEAR, muted=STEEL, rule=SILVER, faint=CHROME, header_fill=CHROME, header_text=BLACK,
                  grid=CHROME, axes_face=WHITE, axes_edge=STEEL,
                  series=(BLACK, STEEL, SILVER, NEAR), pie=(NEAR, STEEL, SILVER, HIGHLIGHT, CHROME),
                  mark="iota-mark-dark.png"),
}
# Chart series dash patterns / markers so series stay distinct without hue.
LINESTYLES = ("-", "--", "-.", ":")
MARKERS = ("o", "s", "^", "D")


def roles(style="charcoal"):
    if style not in ROLES:
        raise ValueError(f"Unknown style '{style}'. Use charcoal or print.")
    return ROLES[style]


def mark_path(style="charcoal"):
    return ASSETS / roles(style)["mark"]


def hex2rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


# ---------- text rules ----------
_DASH = re.compile("[\u2014\u2013\u2012\u2015]")


def clean(value):
    """No em or en dashes, no non-breaking spaces, trimmed."""
    if value is None:
        return ""
    s = str(value)
    s = _DASH.sub("-", s).replace("\u00a0", " ").replace("\u2011", "-")
    s = s.replace("\r\n", "\n").replace("\r", "\n")
    return s.strip()


def slug(text, limit=48):
    s = re.sub(r"[^A-Za-z0-9]+", "-", clean(text)).strip("-").lower()
    return (s[:limit].rstrip("-")) or "output"


# ---------- fonts ----------
FONT_NAME = "Calibri"  # name written into pptx/docx


def _font_dirs():
    dirs = []
    win = os.environ.get("WINDIR") or os.environ.get("SystemRoot")
    if win:
        dirs.append(Path(win) / "Fonts")
    local = os.environ.get("LOCALAPPDATA")
    if local:
        dirs.append(Path(local) / "Microsoft" / "Windows" / "Fonts")
    dirs += [Path("/usr/share/fonts/truetype/sand-box/google/Carlito"), Path("/usr/share/fonts/truetype/crosextra"),
             Path("/usr/share/fonts/truetype/liberation"), Path("/usr/share/fonts/truetype/dejavu")]
    return [d for d in dirs if d.is_dir()]


_FONT_CANDIDATES = {
    "regular": ["calibri.ttf", "Carlito-Regular.ttf", "arial.ttf", "LiberationSans-Regular.ttf", "DejaVuSans.ttf"],
    "bold": ["calibrib.ttf", "Carlito-Bold.ttf", "arialbd.ttf", "LiberationSans-Bold.ttf", "DejaVuSans-Bold.ttf"],
}


def font_file(weight="regular"):
    """Path to a TTF for charts and PDFs. Calibri on Windows, metric twin elsewhere. None if nothing found."""
    for d in _font_dirs():
        for name in _FONT_CANDIDATES[weight]:
            p = d / name
            if p.is_file():
                return p
    return None


# ---------- matplotlib ----------
_MPL_READY = False


def mpl_setup(style="charcoal"):
    """Configure matplotlib for an IOTA chart. Returns the chosen font family name."""
    global _MPL_READY
    import matplotlib
    matplotlib.use("Agg")
    from matplotlib import font_manager as fm
    import matplotlib.pyplot as plt
    family = "DejaVu Sans"
    for w in ("regular", "bold"):
        f = font_file(w)
        if f:
            if not _MPL_READY:
                fm.fontManager.addfont(str(f))
            if w == "regular":
                family = fm.FontProperties(fname=str(f)).get_name()
    _MPL_READY = True
    r = roles(style)
    plt.rcdefaults()
    plt.rcParams.update({
        "font.family": family, "font.size": 13,
        "figure.facecolor": r["field"], "savefig.facecolor": r["field"], "axes.facecolor": r["axes_face"],
        "axes.edgecolor": r["axes_edge"], "axes.labelcolor": r["body"], "axes.titlecolor": r["title"],
        "xtick.color": r["body"], "ytick.color": r["body"], "text.color": r["text"],
        "grid.color": r["grid"], "grid.linewidth": 0.8, "axes.grid": True, "axes.axisbelow": True,
        "legend.facecolor": r["axes_face"], "legend.edgecolor": r["axes_edge"], "legend.labelcolor": r["text"],
    })
    if style == "charcoal":
        plt.rcParams["axes.facecolor"] = NEAR
        plt.rcParams["legend.facecolor"] = NEAR
    return family


# ---------- python-pptx helpers ----------
def pptx_rgb(h):
    from pptx.dml.color import RGBColor
    return RGBColor(*hex2rgb(h))


# ---------- reportlab helpers ----------
_RL_FONTS = None


def rl_fonts():
    """Register Calibri (or twin) with reportlab. Returns (regular, bold) font names."""
    global _RL_FONTS
    if _RL_FONTS:
        return _RL_FONTS
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    reg, bold = font_file("regular"), font_file("bold")
    if reg and bold:
        try:
            pdfmetrics.registerFont(TTFont("IOTA", str(reg)))
            pdfmetrics.registerFont(TTFont("IOTA-Bold", str(bold)))
            _RL_FONTS = ("IOTA", "IOTA-Bold")
            return _RL_FONTS
        except Exception:
            pass
    _RL_FONTS = ("Helvetica", "Helvetica-Bold")
    return _RL_FONTS


def rl_color(h):
    from reportlab.lib import colors
    return colors.HexColor(h)
