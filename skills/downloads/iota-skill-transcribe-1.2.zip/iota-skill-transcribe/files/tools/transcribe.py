"""/transcribe: audio or video to text with the kit's whisper.cpp (whisper-cli).

PyAV decodes any audio or video track to a 16 kHz mono WAV (no ffmpeg install needed).
whisper-cli runs on the CPU and writes JSON with segment times. IOTA writes the
transcript as .txt and .md under output\\transcribe. Meeting notes are a separate step
(the chat model writes a JSON spec, see notes.py).
"""
import json
import os
import re
import subprocess
import sys
import time
import wave
from pathlib import Path

AUDIO_EXT = {".wav", ".mp3", ".m4a", ".flac", ".ogg", ".opus", ".wma", ".aac", ".mp4", ".mkv", ".mov",
             ".webm", ".avi", ".m4v", ".3gp", ".amr"}
KIT = Path(__file__).resolve().parents[3]


def whisper_exe(opts):
    p = opts.get("whisper") or os.environ.get("IOTA_WHISPER_CLI") or str(KIT / "runner" / "voice" / "whisper" / "whisper-cli.exe")
    return Path(p)


def pick_model(opts):
    stt = KIT / "models" / "stt"
    want = str(opts.get("model") or "").lower()
    order = ["ggml-base.en.bin", "ggml-tiny.en.bin"]
    if want in ("tiny", "tiny.en"):
        order = ["ggml-tiny.en.bin", "ggml-base.en.bin"]
    if opts.get("model_path"):
        return Path(opts["model_path"])
    for n in order:
        if (stt / n).is_file():
            return stt / n
    return None


def decode_to_wav(src, dst, progress):
    """Any audio/video file -> 16 kHz mono s16 WAV. Returns duration in seconds."""
    import av
    container = av.open(str(src))
    try:
        astreams = [s for s in container.streams if s.type == "audio"]
        if not astreams:
            raise ValueError(f"{Path(src).name} has no audio track.")
        st = astreams[0]
        dur = None
        if st.duration is not None and st.time_base is not None:
            dur = float(st.duration * st.time_base)
        elif container.duration:
            dur = container.duration / 1_000_000.0
        rs = av.AudioResampler(format="s16", layout="mono", rate=16000)
        written = 0
        last = 0.0
        with wave.open(str(dst), "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(16000)
            for frame in container.decode(st):
                for out in rs.resample(frame):
                    b = bytes(out.planes[0])[: out.samples * 2]
                    w.writeframes(b)
                    written += out.samples
                now = time.time()
                if now - last > 0.5:
                    last = now
                    secs = written / 16000.0
                    if dur:
                        progress(min(secs, dur), dur, f"decoding audio {fmt_ts(secs)} of {fmt_ts(dur)}")
                    else:
                        progress(0, 1, f"decoding audio {fmt_ts(secs)}")
            for out in rs.resample(None):
                b = bytes(out.planes[0])[: out.samples * 2]
                w.writeframes(b)
                written += out.samples
    finally:
        container.close()
    return written / 16000.0


def fmt_ts(sec, ms=False):
    sec = max(0.0, float(sec))
    h = int(sec // 3600)
    m = int(sec % 3600 // 60)
    s = sec % 60
    if ms:
        return f"{h:02d}:{m:02d}:{s:06.3f}"
    return f"{h:02d}:{m:02d}:{int(s):02d}" if h else f"{m:02d}:{int(s):02d}"


def threads(opts):
    t = opts.get("threads")
    if t:
        return max(1, int(t))
    n = os.cpu_count() or 4
    return max(2, min(8, n // 2))


_PROG = re.compile(r"progress\s*=\s*(\d+)%")


def run_whisper(exe, model, wav, out_base, nthreads, progress, dur, extra=None):
    args = ([sys.executable] if str(exe).lower().endswith(".py") else []) + [str(exe), "-m", str(model), "-f", str(wav), "-l", "en", "-t", str(nthreads), "-oj", "-of", str(out_base), "-pp"]
    if extra:
        args += list(extra)
    kw = {}
    if os.name == "nt":
        kw["creationflags"] = 0x08000000  # CREATE_NO_WINDOW
    p = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, **kw)
    tail = []
    buf = b""
    while True:
        ch = p.stdout.read(1)
        if not ch:
            break
        if ch in (b"\n", b"\r"):
            line = buf.decode("utf-8", "replace")
            buf = b""
            if not line.strip():
                continue
            tail.append(line)
            tail = tail[-30:]
            m = _PROG.search(line)
            if m:
                pct = int(m.group(1))
                progress(pct, 100, f"transcribing {pct}%" + (f" of {fmt_ts(dur)}" if dur else ""))
        else:
            buf += ch
    code = p.wait()
    js = Path(str(out_base) + ".json")
    if code != 0 or not js.is_file():
        raise RuntimeError(f"whisper-cli exit {code}. " + " | ".join(t.strip() for t in tail[-6:]))
    return js


def load_segments(js):
    raw = js.read_bytes().decode("utf-8", "replace")
    d = json.loads(raw)
    segs = []
    for s in d.get("transcription", []):
        off = s.get("offsets") or {}
        t = (s.get("text") or "").strip()
        if not t:
            continue
        segs.append(dict(start=float(off.get("from", 0)) / 1000.0, end=float(off.get("to", 0)) / 1000.0, text=t))
    return segs


def merge_paragraphs(segs, max_chars=600, gap=2.0):
    paras = []
    cur = None
    for s in segs:
        if cur and (s["start"] - cur["end"] <= gap) and len(cur["text"]) + len(s["text"]) < max_chars:
            cur["text"] += " " + s["text"]
            cur["end"] = s["end"]
        else:
            if cur:
                paras.append(cur)
            cur = dict(s)
    if cur:
        paras.append(cur)
    return paras


def write_outputs(segs, src_name, dur, model_name, out_dir, stem):
    out_dir.mkdir(parents=True, exist_ok=True)
    txt_p = _unique(out_dir, stem, ".txt")
    md_p = txt_p.with_suffix(".md")
    lines = [f"[{fmt_ts(s['start'])}] {s['text']}" for s in segs]
    txt_p.write_text("\n".join(lines) + "\n", encoding="utf-8")
    paras = merge_paragraphs(segs)
    md = [f"# Transcript: {src_name}", "",
          f"Source: {src_name}  |  Length: {fmt_ts(dur)}  |  Model: {model_name}  |  Made: {time.strftime('%Y-%m-%d %H:%M')}", ""]
    for p in paras:
        md.append(f"**[{fmt_ts(p['start'])}]** {p['text']}")
        md.append("")
    md_p.write_text("\n".join(md), encoding="utf-8")
    return txt_p, md_p


def _unique(folder, stem, ext):
    p = folder / f"{stem}{ext}"
    n = 2
    while p.exists() or p.with_suffix(".md").exists() or p.with_suffix(".txt").exists():
        p = folder / f"{stem}-{n}{ext}"
        n += 1
    return p


def run(inputs, opts, out_dir, tmp_dir, progress):
    t0 = time.time()
    warnings = []
    if not inputs:
        raise ValueError("No audio or video file given. Drop one into the chat, then type /transcribe.")
    src = Path(inputs[0])
    if len(inputs) > 1:
        warnings.append("Only the first file is transcribed. Run /transcribe again for the next one.")
    if not src.is_file():
        raise ValueError(f"File not found: {src}")
    if src.suffix.lower() not in AUDIO_EXT:
        raise ValueError(f"{src.name}: /transcribe reads wav, mp3, m4a, flac, ogg, wma, aac, mp4, mkv, mov or webm.")
    exe = whisper_exe(opts)
    if not exe.is_file():
        raise FileNotFoundError(f"whisper-cli not found at {exe}.")
    model = pick_model(opts)
    if model is None or not model.is_file():
        raise FileNotFoundError("No speech model in models\\stt (ggml-base.en.bin or ggml-tiny.en.bin).")
    tmp_dir.mkdir(parents=True, exist_ok=True)
    tag = f"iota-tr-{os.getpid()}-{int(time.time())}"
    wav = tmp_dir / f"{tag}.wav"
    base = tmp_dir / tag
    try:
        progress(0, 1, "decoding audio")
        dur = decode_to_wav(src, wav, progress)
        if dur < 0.3:
            raise ValueError(f"{src.name}: the audio track is empty.")
        progress(0, 100, f"transcribing 0% of {fmt_ts(dur)}")
        js = run_whisper(exe, model, wav, base, threads(opts), progress, dur)
        segs = load_segments(js)
    finally:
        for p in (wav, Path(str(base) + ".json")):
            try:
                p.unlink()
            except OSError:
                pass
    if not segs:
        warnings.append("No speech was found.")
    model_name = model.name.replace("ggml-", "").replace(".bin", "")
    stem = time.strftime("%Y-%m-%d_%H%M") + "_" + (re.sub(r"[^A-Za-z0-9]+", "-", src.stem).strip("-").lower()[:48] or "audio")
    txt_p, md_p = write_outputs(segs, src.name, dur, model_name, out_dir, stem)
    full = " ".join(s["text"] for s in segs)
    preview = "\n".join(f"[{fmt_ts(s['start'])}] {s['text']}" for s in segs)
    elapsed = time.time() - t0
    meta = dict(duration_s=round(dur, 1), segments=len(segs), words=len(full.split()), model=model_name,
                threads=threads(opts), device="CPU", ms=int(elapsed * 1000),
                speed=round(dur / elapsed, 2) if elapsed > 0 else None)
    return dict(text=preview, transcript_txt=str(txt_p), transcript_md=str(md_p), files=[str(txt_p), str(md_p)],
                warnings=warnings, meta=meta, chars=len(full))
