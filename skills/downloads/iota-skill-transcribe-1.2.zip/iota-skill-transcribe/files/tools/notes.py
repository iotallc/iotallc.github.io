"""Meeting notes from a transcript. The chat model returns a JSON spec; IOTA checks it and
writes <transcript>-notes.md next to the transcript. No numbers are computed here."""
import re
from pathlib import Path

MAX_ITEMS = 40


def _clean(s, lim=600):
    s = re.sub(r"[\u2012-\u2015]", "-", str(s or "")).replace("\u00a0", " ").strip()
    return s[:lim]


def check(spec, ctx):
    if not isinstance(spec, dict):
        ctx.err("Spec must be a JSON object with summary, decisions and actions.")
        return {}
    summ = spec.get("summary")
    if isinstance(summ, list):
        summ = [_clean(x) for x in summ if _clean(x)]
    elif isinstance(summ, str) and summ.strip():
        summ = [_clean(summ, 2000)]
    else:
        ctx.err("'summary' is missing (a short paragraph or a list of points).")
        summ = []
    dec = spec.get("decisions", [])
    if isinstance(dec, str):
        dec = [dec]
    if not isinstance(dec, list):
        ctx.err("'decisions' must be a list of text lines.")
        dec = []
    dec = [_clean(x if not isinstance(x, dict) else (x.get("decision") or x.get("text") or "")) for x in dec]
    dec = [x for x in dec if x][:MAX_ITEMS]
    acts_in = spec.get("actions", spec.get("action_items", []))
    if not isinstance(acts_in, list):
        ctx.err("'actions' must be a list of {item, owner, due}.")
        acts_in = []
    acts = []
    for i, a in enumerate(acts_in[:MAX_ITEMS]):
        if isinstance(a, str):
            a = {"item": a}
        if not isinstance(a, dict):
            ctx.err(f"actions[{i}] must be an object with 'item'.")
            continue
        item = _clean(a.get("item") or a.get("task") or a.get("action"))
        if not item:
            ctx.warn(f"actions[{i}] had no 'item' and was skipped.")
            continue
        acts.append(dict(item=item, owner=_clean(a.get("owner") or a.get("who") or "", 80) or "not stated",
                         due=_clean(a.get("due") or a.get("when") or "", 60) or "not stated"))
    topics = spec.get("topics") or []
    topics = [_clean(x, 200) for x in topics if isinstance(x, (str, int, float)) and _clean(x)] if isinstance(topics, list) else []
    return dict(title=_clean(spec.get("title") or "Meeting notes", 120), summary=summ, decisions=dec, actions=acts,
                topics=topics[:MAX_ITEMS])


def render(norm, transcript_md, out_path=None):
    tp = Path(transcript_md)
    out = Path(out_path) if out_path else tp.with_name(tp.stem + "-notes.md")
    n = 2
    while out.exists():
        out = tp.with_name(f"{tp.stem}-notes-{n}.md")
        n += 1
    L = [f"# {norm['title']}", "", f"From the transcript: {tp.name}", "", "## Summary", ""]
    L += [f"- {s}" for s in norm["summary"]] if len(norm["summary"]) > 1 else [norm["summary"][0] if norm["summary"] else "Not stated."]
    if norm.get("topics"):
        L += ["", "## Topics", ""] + [f"- {t}" for t in norm["topics"]]
    L += ["", "## Decisions", ""]
    L += [f"- {d}" for d in norm["decisions"]] or ["- None recorded."]
    L += ["", "## Action items", "", "| Item | Owner | Due |", "|---|---|---|"]
    if norm["actions"]:
        for a in norm["actions"]:
            L.append(f"| {a['item'].replace('|', '/')} | {a['owner'].replace('|', '/')} | {a['due'].replace('|', '/')} |")
    else:
        L.append("| None recorded. | | |")
    L += ["", "_Written by the chat model from the transcript. Check names and dates against the recording._", ""]
    out.write_text("\n".join(L), encoding="utf-8")
    # Chat version: no headings or tables (the chat shows bold, italics and bullets).
    C = [f"**{norm['title']}**", "", "**Summary**"]
    C += [f"- {s}" for s in norm["summary"]] or ["- Not stated."]
    C += ["", "**Decisions**"] + ([f"- {d}" for d in norm["decisions"]] or ["- None recorded."])
    C += ["", "**Action items**"]
    C += [f"- {a['item']} (owner: {a['owner']}, due: {a['due']})" for a in norm["actions"]] or ["- None recorded."]
    return out, "\n".join(C)
