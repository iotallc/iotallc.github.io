"""Spec validation for skills. Small hand-written checks (no extra library).

Each check returns (normalized_spec, errors, warnings). Error messages are plain
and name the field so the model can fix them on the single retry.
"""
from pathlib import Path
import iota_theme as T

LIMITS = dict(series=4, points=5000, pie_slices=5, slides=30, bullets=8, table_rows=14, table_cols=6,
              pdf_blocks=200, pdf_table_rows=200, text_len=4000, title_len=120)
CHART_TYPES = ("bar", "line", "pie", "scatter")
SLIDE_LAYOUTS = ("title", "bullets", "chart", "table", "two_column")
PDF_BLOCKS = ("heading", "text", "bullets", "table", "chart", "page_break")


class Ctx:
    def __init__(self):
        self.errors, self.warnings = [], []

    def err(self, msg):
        self.errors.append(msg)

    def warn(self, msg):
        self.warnings.append(msg)


def _num(v):
    if isinstance(v, bool):
        raise ValueError
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace(",", "").replace("%", "")
    return float(s)


def _str(ctx, d, key, where, required=True, limit=None):
    v = d.get(key)
    if v is None or (isinstance(v, str) and not v.strip()):
        if required:
            ctx.err(f"{where}: '{key}' is missing.")
        return ""
    if not isinstance(v, (str, int, float)):
        ctx.err(f"{where}: '{key}' must be text.")
        return ""
    s = T.clean(v)
    lim = limit or LIMITS["text_len"]
    if len(s) > lim:
        ctx.warn(f"{where}: '{key}' cut to {lim} characters.")
        s = s[:lim]
    return s


def _str_list(ctx, d, key, where, max_items=None, required=True):
    v = d.get(key)
    if v is None:
        if required:
            ctx.err(f"{where}: '{key}' is missing (a list of text lines).")
        return []
    if isinstance(v, str):
        v = [v]
    if not isinstance(v, list) or not all(isinstance(x, (str, int, float)) for x in v):
        ctx.err(f"{where}: '{key}' must be a list of text lines.")
        return []
    out = [T.clean(x) for x in v if T.clean(x)]
    if max_items and len(out) > max_items:
        ctx.warn(f"{where}: only the first {max_items} items of '{key}' are used.")
        out = out[:max_items]
    if required and not out:
        ctx.err(f"{where}: '{key}' is empty.")
    return out


def _num_list(ctx, v, where):
    if not isinstance(v, list) or not v:
        ctx.err(f"{where} must be a non-empty list of numbers.")
        return []
    out = []
    for i, x in enumerate(v):
        try:
            out.append(_num(x))
        except (ValueError, TypeError):
            ctx.err(f"{where}[{i}] is '{x}', not a number.")
            return []
    if len(out) > LIMITS["points"]:
        ctx.err(f"{where} has {len(out)} points. The limit is {LIMITS['points']}.")
    return out


# ---------- data files ----------
def load_table(path, sheet=None):
    """Read CSV or XLSX into (headers, rows). Cells are strings or numbers."""
    p = Path(path)
    if not p.is_file():
        raise FileNotFoundError(f"Data file not found: {p}")
    ext = p.suffix.lower()
    if ext in (".csv", ".txt", ".tsv"):
        import csv
        raw = p.read_text(encoding="utf-8-sig", errors="replace")
        try:
            dialect = csv.Sniffer().sniff(raw[:4096], delimiters=",;\t|")
        except csv.Error:
            dialect = csv.excel
        rows = [r for r in csv.reader(raw.splitlines(), dialect) if any(c.strip() for c in r)]
    elif ext in (".xlsx", ".xlsm"):
        from openpyxl import load_workbook
        wb = load_workbook(p, read_only=True, data_only=True)
        ws = wb[sheet] if sheet else wb.worksheets[0]
        rows = [["" if c is None else c for c in r] for r in ws.iter_rows(values_only=True)]
        rows = [r for r in rows if any(str(c).strip() for c in r)]
        wb.close()
    else:
        raise ValueError(f"Unsupported data file type '{ext}'. Use CSV or XLSX.")
    if len(rows) < 2:
        raise ValueError(f"Data file {p.name} has no data rows.")
    headers = [T.clean(h) for h in rows[0]]
    return headers, rows[1:]


def _column(ctx, headers, rows, name, numeric, where):
    if name not in headers:
        ctx.err(f'{where}: column "{name}" not found. Columns: {", ".join(headers)}.')
        return []
    i = headers.index(name)
    vals = [r[i] if i < len(r) else "" for r in rows]
    if not numeric:
        return [T.clean(v) for v in vals]
    out = []
    for n, v in enumerate(vals, 2):
        try:
            out.append(_num(v))
        except (ValueError, TypeError):
            ctx.err(f'{where}: column "{name}" row {n} is "{v}", not a number.')
            return []
    return out


def _chart_from_file(ctx, spec, where):
    d = spec["data"]
    if not isinstance(d, dict) or not d.get("file"):
        ctx.err(f"{where}: 'data' needs 'file' plus column names.")
        return
    try:
        headers, rows = load_table(d["file"], d.get("sheet"))
    except Exception as e:  # noqa: BLE001
        ctx.err(f"{where}: {e}")
        return
    t = spec.get("type")
    if t == "pie":
        spec["labels"] = _column(ctx, headers, rows, d.get("labels", ""), False, where)
        spec["values"] = _column(ctx, headers, rows, d.get("values", ""), True, where)
        return
    ys = d.get("y") or []
    if isinstance(ys, str):
        ys = [ys]
    if not ys:
        ctx.err(f"{where}: 'data.y' needs at least one column name. Columns: {', '.join(headers)}.")
        return
    if t == "scatter":
        xs = _column(ctx, headers, rows, d.get("x", ""), True, where)
        spec["series"] = [{"name": y, "x": xs, "y": _column(ctx, headers, rows, y, True, where)} for y in ys]
    else:
        spec["x"] = _column(ctx, headers, rows, d.get("x", ""), False, where)
        spec["series"] = [{"name": y, "values": _column(ctx, headers, rows, y, True, where)} for y in ys]
    spec["data"] = {k: v for k, v in d.items()}


# ---------- chart ----------
def check_chart(spec, ctx=None, where="chart", need_title=True):
    ctx = ctx or Ctx()
    if not isinstance(spec, dict):
        ctx.err(f"{where} must be a JSON object.")
        return {}, ctx
    s = dict(spec)
    t = str(s.get("type", "")).lower().strip()
    if t not in CHART_TYPES:
        ctx.err(f"{where}: 'type' is '{s.get('type')}'. Use one of: {', '.join(CHART_TYPES)}.")
        return s, ctx
    s["type"] = t
    s["title"] = _str(ctx, s, "title", where, required=need_title, limit=LIMITS["title_len"])
    for k in ("subtitle", "x_label", "y_label", "source"):
        s[k] = _str(ctx, s, k, where, required=False, limit=200)
    if s.get("data") is not None:
        _chart_from_file(ctx, s, where)
        if ctx.errors:
            return s, ctx
    if t == "pie":
        labels = _str_list(ctx, s, "labels", where)
        values = _num_list(ctx, s.get("values"), f"{where}.values")
        if labels and values and len(labels) != len(values):
            ctx.err(f"{where}: {len(labels)} labels but {len(values)} values.")
        if values and any(v < 0 for v in values):
            ctx.err(f"{where}: pie values cannot be negative.")
        if values and sum(values) <= 0:
            ctx.err(f"{where}: pie values add up to zero.")
        n = LIMITS["pie_slices"]
        if not ctx.errors and len(values) > n:
            pairs = sorted(zip(values, labels), reverse=True)
            keep, rest = pairs[:n - 1], pairs[n - 1:]
            values = [v for v, _ in keep] + [sum(v for v, _ in rest)]
            labels = [l for _, l in keep] + ["Other"]
            ctx.warn(f"{where}: {len(pairs)} slices; the smallest {len(rest)} were grouped as Other.")
        s["labels"], s["values"] = labels, values
        return s, ctx
    series = s.get("series")
    if not isinstance(series, list) or not series:
        ctx.err(f"{where}: 'series' is missing (a list of {{name, values}}).")
        return s, ctx
    if len(series) > LIMITS["series"]:
        ctx.err(f"{where}: {len(series)} series. The limit is {LIMITS['series']} so each stays readable in greys.")
        return s, ctx
    out = []
    if t == "scatter":
        for i, se in enumerate(series):
            w = f"{where}.series[{i}]"
            if not isinstance(se, dict):
                ctx.err(f"{w} must be an object with name, x and y.")
                continue
            xs, ys = _num_list(ctx, se.get("x"), f"{w}.x"), _num_list(ctx, se.get("y"), f"{w}.y")
            if xs and ys and len(xs) != len(ys):
                ctx.err(f"{w}: {len(xs)} x values but {len(ys)} y values.")
            out.append({"name": T.clean(se.get("name") or f"Series {i + 1}"), "x": xs, "y": ys})
    else:
        x = s.get("x")
        if not isinstance(x, list) or not x:
            ctx.err(f"{where}: 'x' is missing (the category or x-axis values).")
            return s, ctx
        s["x"] = [T.clean(v) if isinstance(v, str) else v for v in x]
        for i, se in enumerate(series):
            w = f"{where}.series[{i}]"
            if not isinstance(se, dict):
                ctx.err(f"{w} must be an object with name and values.")
                continue
            vals = _num_list(ctx, se.get("values"), f"{w}.values")
            if vals and len(vals) != len(x):
                ctx.err(f"{w}: {len(vals)} values but {len(x)} x entries.")
            out.append({"name": T.clean(se.get("name") or f"Series {i + 1}"), "values": vals})
    s["series"] = out
    return s, ctx


# ---------- table helper ----------
def _table(ctx, b, where, max_rows, max_cols):
    cols = _str_list(ctx, b, "columns", where)
    rows = b.get("rows")
    if not isinstance(rows, list) or not rows:
        ctx.err(f"{where}: 'rows' is missing (a list of rows, each a list of cells).")
        return cols, []
    if len(cols) > max_cols:
        ctx.err(f"{where}: {len(cols)} columns. The limit is {max_cols}.")
    clean_rows = []
    for i, r in enumerate(rows):
        if not isinstance(r, list):
            ctx.err(f"{where}: row {i + 1} must be a list of cells.")
            continue
        if cols and len(r) != len(cols):
            ctx.err(f"{where}: row {i + 1} has {len(r)} cells but there are {len(cols)} columns.")
            continue
        clean_rows.append([T.clean(c) for c in r])
    if len(clean_rows) > max_rows:
        ctx.warn(f"{where}: only the first {max_rows} rows are shown.")
        clean_rows = clean_rows[:max_rows]
    return cols, clean_rows


def _widths(ctx, b, n, where):
    w = b.get("col_widths")
    if w is None:
        return None
    try:
        w = [float(x) for x in w]
    except (TypeError, ValueError):
        ctx.warn(f"{where}: 'col_widths' ignored (not numbers).")
        return None
    if len(w) != n or min(w) <= 0:
        ctx.warn(f"{where}: 'col_widths' ignored (needs {n} positive numbers).")
        return None
    tot = sum(w)
    return [x / tot for x in w]


# ---------- deck ----------
def check_deck(spec, ctx=None):
    ctx = ctx or Ctx()
    if not isinstance(spec, dict):
        ctx.err("deck must be a JSON object.")
        return {}, ctx
    s = dict(spec)
    s["title"] = _str(ctx, s, "title", "deck", limit=LIMITS["title_len"])
    s["footer"] = _str(ctx, s, "footer", "deck", required=False, limit=120)
    slides = s.get("slides")
    if not isinstance(slides, list) or not slides:
        ctx.err("deck: 'slides' is missing (a list of slides).")
        return s, ctx
    if len(slides) > LIMITS["slides"]:
        ctx.err(f"deck: {len(slides)} slides. The limit is {LIMITS['slides']}.")
        return s, ctx
    out = []
    for i, sl in enumerate(slides):
        w = f"slide {i + 1}"
        if not isinstance(sl, dict):
            ctx.err(f"{w} must be an object.")
            continue
        sl = dict(sl)
        k = str(sl.get("layout", "")).lower().strip().replace("-", "_").replace(" ", "_")
        if k == "twocolumn":
            k = "two_column"
        if k not in SLIDE_LAYOUTS:
            ctx.err(f"{w}: layout is '{sl.get('layout')}'. Use one of: {', '.join(SLIDE_LAYOUTS)}.")
            continue
        sl["layout"] = k
        sl["title"] = _str(ctx, sl, "title", w, limit=LIMITS["title_len"])
        if k == "title":
            sl["subtitle"] = _str(ctx, sl, "subtitle", w, required=False, limit=200)
            sl["meta"] = _str(ctx, sl, "meta", w, required=False, limit=120)
        elif k == "bullets":
            sl["bullets"] = _str_list(ctx, sl, "bullets", w, LIMITS["bullets"])
            note = sl.get("note")
            if note is not None:
                if isinstance(note, dict):
                    sl["note"] = {"label": T.clean(note.get("label", "")), "lines": _str_list(ctx, note, "lines", f"{w} note", 6)}
                else:
                    ctx.warn(f"{w}: 'note' ignored (needs label and lines).")
                    sl.pop("note")
        elif k == "chart":
            c, _ = check_chart(sl.get("chart"), ctx, f"{w} chart", need_title=False)
            sl["chart"] = c
            sl["caption"] = _str(ctx, sl, "caption", w, required=False, limit=200)
        elif k == "table":
            sl["columns"], sl["rows"] = _table(ctx, sl, w, LIMITS["table_rows"], LIMITS["table_cols"])
            sl["col_widths"] = _widths(ctx, sl, len(sl["columns"]), w)
            sl["caption"] = _str(ctx, sl, "caption", w, required=False, limit=200)
        elif k == "two_column":
            cols = sl.get("columns")
            if not isinstance(cols, list) or len(cols) != 2 or not all(isinstance(c, dict) for c in cols):
                ctx.err(f"{w}: 'columns' must be exactly 2 objects with heading and bullets.")
            else:
                sl["columns"] = [{"heading": _str(ctx, c, "heading", f"{w} column {j + 1}", limit=80),
                                  "bullets": _str_list(ctx, c, "bullets", f"{w} column {j + 1}", 6)} for j, c in enumerate(cols)]
        out.append(sl)
    s["slides"] = out
    return s, ctx


# ---------- pdf ----------
def check_pdf(spec, ctx=None):
    ctx = ctx or Ctx()
    if not isinstance(spec, dict):
        ctx.err("pdf must be a JSON object.")
        return {}, ctx
    s = dict(spec)
    s["title"] = _str(ctx, s, "title", "pdf", limit=LIMITS["title_len"])
    s["subtitle"] = _str(ctx, s, "subtitle", "pdf", required=False, limit=200)
    st = str(s.get("style") or "charcoal").lower()
    if st not in T.STYLES:
        ctx.warn(f"pdf: style '{st}' unknown, using charcoal.")
        st = "charcoal"
    s["style"] = st
    ps = str(s.get("page_size") or "letter").lower()
    if ps not in ("letter", "a4"):
        ctx.warn(f"pdf: page_size '{ps}' unknown, using letter.")
        ps = "letter"
    s["page_size"] = ps
    blocks = s.get("blocks")
    if not isinstance(blocks, list) or not blocks:
        ctx.err("pdf: 'blocks' is missing (a list of heading, text, bullets, table, chart, page_break).")
        return s, ctx
    if len(blocks) > LIMITS["pdf_blocks"]:
        ctx.err(f"pdf: {len(blocks)} blocks. The limit is {LIMITS['pdf_blocks']}.")
        return s, ctx
    out = []
    for i, b in enumerate(blocks):
        w = f"block {i + 1}"
        if not isinstance(b, dict):
            ctx.err(f"{w} must be an object.")
            continue
        b = dict(b)
        k = str(b.get("type", "")).lower().strip()
        if k not in PDF_BLOCKS:
            ctx.err(f"{w}: type is '{b.get('type')}'. Use one of: {', '.join(PDF_BLOCKS)}.")
            continue
        b["type"] = k
        if k in ("heading", "text"):
            b["text"] = _str(ctx, b, "text", w)
        elif k == "bullets":
            b["items"] = _str_list(ctx, b, "items", w, 30)
        elif k == "table":
            b["columns"], b["rows"] = _table(ctx, b, w, LIMITS["pdf_table_rows"], 8)
            b["col_widths"] = _widths(ctx, b, len(b["columns"]), w)
            b["caption"] = _str(ctx, b, "caption", w, required=False, limit=200)
        elif k == "chart":
            c, _ = check_chart(b.get("chart"), ctx, f"{w} chart", need_title=False)
            b["chart"] = c
            b["caption"] = _str(ctx, b, "caption", w, required=False, limit=200)
        out.append(b)
    s["blocks"] = out
    return s, ctx


CHECKS = {"chart": lambda s: check_chart(s), "deck": lambda s: check_deck(s), "pdf": lambda s: check_pdf(s)}
