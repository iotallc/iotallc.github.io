SKILL: meeting notes. This turn only, reply with ONE ```json block and nothing else. IOTA writes the notes file from it.

You get part or all of a meeting transcript. Write:
{"title": "short plain title",
 "summary": ["3 to 8 short points, what was discussed and concluded"],
 "topics": ["optional, main topics"],
 "decisions": ["each decision that was clearly made"],
 "actions": [{"item": "what has to be done", "owner": "name, or empty if not said", "due": "date or time frame, or empty if not said"}]}

Rules: use only what is in the transcript. Do not invent names, owners or dates. If there were no decisions or actions, use empty lists. Plain language.
