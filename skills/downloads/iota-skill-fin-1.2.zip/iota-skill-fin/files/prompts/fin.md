SKILL: fin. This turn only, reply with ONE ```json block and nothing else. IOTA's Python does all the math from it. Do not calculate anything yourself and do not write code.

Schema:
{"currency": "$" (optional), "chart": false, "items": [ ...one object per calculation, up to 12... ]}
Set "chart": true only when the user asks for a chart or graph.

Rates are decimals (0.08) or text with a percent sign ("8%"). Amounts are plain numbers. Cash flow lists start at t=0 (the investment, usually negative).

Item types ("op"):
- npv: {"op": "npv", "rate": 0.08, "cashflows": [-1000, 300, 400, 500]}   (add "first_at": 1 only if the user wants Excel's NPV convention)
- irr: {"op": "irr", "cashflows": [-1000, 300, 400, 500]}
- xnpv: {"op": "xnpv", "rate": 0.09, "cashflows": [...], "dates": ["2026-01-01", ...]}
- xirr: {"op": "xirr", "cashflows": [...], "dates": ["2026-01-01", ...]}
- payback: {"op": "payback", "cashflows": [...]}
- discounted_payback: {"op": "discounted_payback", "rate": 0.08, "cashflows": [...]}
- loan_payment: {"op": "loan_payment", "principal": 250000, "annual_rate": 0.065, "years": 30, "periods_per_year": 12}
- amortization: same fields as loan_payment, plus optional "start_date": "2026-11-01", "extra_payment": 100, "title". IOTA writes the table as .xlsx.
- cagr: {"op": "cagr", "start_value": 100, "end_value": 180, "years": 5}
- fv: {"op": "fv", "rate": 0.05, "nper": 10, "pv": 1000, "pmt": 100, "when": "end"}
- pv: {"op": "pv", "rate": 0.05, "nper": 10, "fv": 2000, "pmt": 0}
- wacc: {"op": "wacc", "equity": 600, "debt": 400, "cost_of_equity": 0.11, "cost_of_debt": 0.06, "tax_rate": 0.25}
- break_even: {"op": "break_even", "fixed_costs": 50000, "price": 25, "variable_cost": 15}
- dcf: {"op": "dcf", "cashflows": [year 1, year 2, ...], "rate": 0.10, "terminal_growth": 0.02 (or "terminal_multiple": 8), "net_debt": 0, "shares": optional, "title"}. IOTA writes the table as .xlsx.

Rules: use only numbers the user gave or that are in the conversation. Do not invent cash flows. Use one item per question.

Example:
```json
{"currency": "$", "items": [{"op": "npv", "rate": 0.08, "cashflows": [-1000, 300, 400, 500]}, {"op": "irr", "cashflows": [-1000, 300, 400, 500]}]}
```
