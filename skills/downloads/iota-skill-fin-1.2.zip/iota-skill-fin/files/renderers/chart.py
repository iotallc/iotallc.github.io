"""Chart renderer: validated chart spec -> PNG. Deterministic, no model code."""
import iota_theme as T


def render(spec, out_path, style="charcoal", size=(10, 5.6), dpi=150, mark=True, field=None, show_titles=True):
    T.mpl_setup(style)
    import matplotlib.pyplot as plt
    import matplotlib.image as mpimg
    r = T.roles(style)
    field = field or r["field"]
    t = spec["type"]
    fig, ax = plt.subplots(figsize=size, dpi=dpi)
    fig.set_facecolor(field)
    if field == T.NEAR:
        ax.set_facecolor(T.BLACK)  # plot area stays distinct on a charcoal page
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    series = spec.get("series", [])
    sc = r["series"]
    if t == "bar":
        n = len(series)
        w = 0.8 / max(n, 1)
        for i, s in enumerate(series):
            xs = [j + (i - (n - 1) / 2) * w for j in range(len(spec["x"]))]
            ax.bar(xs, s["values"], w * 0.92, label=s["name"], color=sc[i % 4],
                   edgecolor=r["axes_edge"] if style == "print" and sc[i % 4] in ("#FFFFFF",) else None)
        ax.set_xticks(range(len(spec["x"])))
        ax.set_xticklabels([str(x) for x in spec["x"]])
        ax.grid(axis="x", visible=False)
    elif t == "line":
        xs = spec["x"]
        if not all(isinstance(v, (int, float)) for v in xs):
            xs = [str(v) for v in xs]
        for i, s in enumerate(series):
            ax.plot(xs, s["values"], label=s["name"], color=sc[i % 4], lw=2.4, marker=T.MARKERS[i % 4],
                    ms=5, linestyle=T.LINESTYLES[i % 4])
    elif t == "scatter":
        for i, s in enumerate(series):
            ax.scatter(s["x"], s["y"], label=s["name"], color=sc[i % 4], s=34, marker=T.MARKERS[i % 4],
                       edgecolors=field, linewidths=0.5)
    elif t == "pie":
        ax.grid(False)
        ax.set_facecolor(field)
        ax.axis("equal")
        cols = list(r["pie"])[:len(spec["values"])]
        _, _, pct = ax.pie(spec["values"], labels=spec["labels"], colors=cols, autopct="%1.0f%%", startangle=90,
                           counterclock=False, pctdistance=0.72,
                           wedgeprops=dict(edgecolor=field, linewidth=2, width=0.55),
                           textprops=dict(color=r["text"], fontsize=13))
        dark = {T.BLACK, T.NEAR, T.STEEL}
        for p, c in zip(pct, cols):
            p.set_color(T.CHROME if c in dark else T.BLACK)
            p.set_fontsize(12)
    if t != "pie":
        ax.set_xlabel(spec.get("x_label", ""))
        ax.set_ylabel(spec.get("y_label", ""))
        if len(series) > 1:
            ax.legend(frameon=True, loc="best")
    has_title = show_titles and bool(spec.get("title"))
    if has_title:
        fig.suptitle(spec["title"], x=0.06, y=0.96, ha="left", fontsize=19, fontweight="bold", color=r["title"])
        if spec.get("subtitle"):
            fig.text(0.06, 0.885, spec["subtitle"], ha="left", fontsize=12, color=r["body"])
    if show_titles and spec.get("source"):
        fig.text(0.06, 0.025, spec["source"], ha="left", fontsize=10, color=r["muted"])
    top = (0.86 if spec.get("subtitle") else 0.90) if has_title else 1.0
    bottom = 0.06 if (show_titles and spec.get("source")) or mark else 0.0
    fig.tight_layout(rect=(0.02, bottom, 0.98, top))
    if mark and T.mark_path(style).exists():
        m = mpimg.imread(str(T.mark_path(style)))
        mh = 0.045
        mx = fig.add_axes([0.935, 0.015, mh * size[1] / size[0], mh])
        mx.imshow(m)
        mx.axis("off")
    fig.savefig(str(out_path), facecolor=field)
    plt.close(fig)
    return out_path
