"""/fin: finance math (NPV, IRR, XNPV, XIRR, payback, loans, amortization, CAGR, FV, PV, WACC,
break-even, simple DCF). Plain Python, no model arithmetic. Amortization and DCF tables go to
output\\fin as .xlsx with live formulas, plus an optional chart PNG in the /chart theme.
"""
import datetime as dt
import math
import re

MAX_ITEMS = 12
MAX_FLOWS = 600


class FinError(ValueError):
    pass


# ---------- parsing ----------
def num(v, where):
    if isinstance(v, bool) or v is None:
        raise FinError(f"{where}: needs a number.")
    if isinstance(v, (int, float)):
        x = float(v)
    else:
        s = str(v).strip().replace(",", "").replace("$", "").replace("€", "").replace("£", "")
        neg = s.startswith("(") and s.endswith(")")
        s = s.strip("()")
        mult = 1.0
        m = re.match(r"^([-+]?\d*\.?\d+(?:[eE][-+]?\d+)?)\s*([kKmMbB]|mm|MM)?$", s)
        if not m:
            raise FinError(f"{where}: '{v}' is not a number.")
        suf = (m.group(2) or "").lower()
        mult = {"k": 1e3, "m": 1e6, "mm": 1e6, "b": 1e9}.get(suf, 1.0)
        x = float(m.group(1)) * mult * (-1 if neg else 1)
    if not math.isfinite(x):
        raise FinError(f"{where}: number is not finite.")
    return x


def rate(v, where, warnings, allow_neg=False):
    """'8%' -> 0.08, 0.08 -> 0.08, 8 -> 0.08 (with a note)."""
    if isinstance(v, str) and v.strip().endswith("%"):
        r = num(v.strip()[:-1], where) / 100.0
    else:
        r = num(v, where)
        if abs(r) > 1.0:
            warnings.append(f"{where}: {fmt_num(r)} read as {fmt_num(r)}%.")
            r = r / 100.0
    if r <= -1.0 or (r < 0 and not allow_neg):
        raise FinError(f"{where}: rate {fmt_pct(r)} is out of range.")
    return r


def flows(v, where):
    if not isinstance(v, list) or not v:
        raise FinError(f"{where}: 'cashflows' must be a non-empty list of numbers.")
    if len(v) > MAX_FLOWS:
        raise FinError(f"{where}: at most {MAX_FLOWS} cash flows.")
    return [num(x, f"{where}[{i}]") for i, x in enumerate(v)]


def parse_date(v, where):
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        # Excel serial date
        return dt.date(1899, 12, 30) + dt.timedelta(days=int(v))
    s = str(v or "").strip()
    for f in ("%Y-%m-%d", "%m/%d/%Y", "%m/%d/%y", "%d %b %Y", "%b %d, %Y", "%d %B %Y", "%B %d, %Y", "%Y/%m/%d"):
        try:
            return dt.datetime.strptime(s, f).date()
        except ValueError:
            pass
    raise FinError(f"{where}: '{s}' is not a date (use YYYY-MM-DD).")


# ---------- formatting ----------
def fmt_num(x, dp=2):
    if x is None or (isinstance(x, float) and not math.isfinite(x)):
        return "n/a"
    s = f"{x:,.{dp}f}"
    return s


def fmt_money(x, cur=""):
    if x is None:
        return "n/a"
    neg = x < 0
    s = f"{abs(x):,.2f}"
    return ("-" if neg else "") + cur + s


def fmt_pct(r, dp=2):
    return f"{r * 100:,.{dp}f}%"


# ---------- core math ----------
def npv(r, cfs, first_at=0):
    return sum(cf / (1.0 + r) ** (i + first_at) for i, cf in enumerate(cfs))


def xnpv(r, cfs, dates):
    d0 = dates[0]
    return sum(cf / (1.0 + r) ** ((d - d0).days / 365.0) for cf, d in zip(cfs, dates))


def _roots(f, lo=-0.9999, hi=100.0, steps=4000):
    """All sign changes of f on a log-ish grid, refined by bisection."""
    pts = []
    # dense near 0, sparse far out
    for i in range(steps + 1):
        t = i / steps
        pts.append(lo + (hi - lo) * (t ** 3))
    roots = []
    prev_x, prev_y = None, None
    for x in pts:
        try:
            y = f(x)
        except (OverflowError, ZeroDivisionError):
            prev_x, prev_y = None, None
            continue
        if not math.isfinite(y):
            prev_x, prev_y = None, None
            continue
        if y == 0:
            roots.append(x)
        elif prev_y is not None and (prev_y < 0) != (y < 0):
            a, b, fa = prev_x, x, prev_y
            for _ in range(200):
                m = (a + b) / 2
                fm = f(m)
                if (fa < 0) == (fm < 0):
                    a, fa = m, fm
                else:
                    b = m
                if b - a < 1e-14:
                    break
            roots.append((a + b) / 2)
        prev_x, prev_y = x, y
    out = []
    for r in roots:
        if not any(abs(r - o) < 1e-9 for o in out):
            out.append(r)
    return out


def _pick(roots, w, where):
    if not roots:
        raise FinError(f"{where}: no rate makes NPV zero. Cash flows need at least one sign change.")
    if len(roots) > 1:
        w.append(f"{where}: cash flows change sign more than once, so there are {len(roots)} rates that work "
                 f"({', '.join(fmt_pct(x, 4) for x in roots)}). The one nearest 10% is shown.")
    return min(roots, key=lambda x: abs(x - 0.10))


def irr(cfs, w=None, where="irr"):
    w = [] if w is None else w
    return _pick(_roots(lambda r: npv(r, cfs)), w, where)


def xirr(cfs, dates, w=None, where="xirr"):
    w = [] if w is None else w
    return _pick(_roots(lambda r: xnpv(r, cfs, dates)), w, where)


def payback(cfs, r=None):
    cum = 0.0
    prev = 0.0
    for t, cf in enumerate(cfs):
        v = cf / (1.0 + r) ** t if r is not None else cf
        prev = cum
        cum += v
        if t > 0 and prev < 0 <= cum:
            return (t - 1) + (-prev / v if v else 0.0)
    return None


def pmt(principal, r_period, n):
    if n <= 0:
        raise FinError("Number of payments must be above zero.")
    if r_period == 0:
        return principal / n
    return principal * r_period / (1.0 - (1.0 + r_period) ** -n)


def amort_rows(principal, r_period, n, payment, extra=0.0):
    rows = []
    bal = principal
    for k in range(1, n + 1):
        interest = bal * r_period
        princ = min(payment - interest + extra, bal)
        pay = interest + princ
        bal = bal - princ
        if abs(bal) < 0.005:
            bal = 0.0
        rows.append((k, pay, interest, princ, bal))
        if bal <= 0:
            break
    return rows


def add_months(d, m):
    y = d.year + (d.month - 1 + m) // 12
    mo = (d.month - 1 + m) % 12 + 1
    import calendar
    day = min(d.day, calendar.monthrange(y, mo)[1])
    return dt.date(y, mo, day)


# ---------- ops ----------
def _flows_text(cfs, cur, start=0):
    shown = cfs if len(cfs) <= 12 else cfs[:10] + [None] + cfs[-1:]
    parts = []
    for x in shown:
        parts.append("..." if x is None else fmt_money(x, cur))
    return f"t={start}..{start + len(cfs) - 1}: " + "; ".join(parts)


def op_npv(it, where, w, cur, ctx):
    r = rate(it.get("rate"), where + " rate", w)
    cfs = flows(it.get("cashflows"), where + " cashflows")
    first = 1 if str(it.get("first_at", 0)) in ("1", "end") or it.get("excel") else 0
    v = npv(r, cfs, first)
    return "NPV", [f"Inputs: rate {fmt_pct(r)}, cash flows {_flows_text(cfs, cur, first)}",
                   "Formula: NPV = Σ CFₜ / (1 + r)ᵗ" + (" (first cash flow at t=1, as Excel NPV)" if first else " (first cash flow at t=0, not discounted)"),
                   f"Result: **NPV = {fmt_money(v, cur)}**"], {"npv": v}


def op_irr(it, where, w, cur, ctx):
    cfs = flows(it.get("cashflows"), where + " cashflows")
    r = irr(cfs, w, where)
    return "IRR", [f"Inputs: cash flows {_flows_text(cfs, cur)}",
                   "Formula: find r where Σ CFₜ / (1 + r)ᵗ = 0",
                   f"Result: **IRR = {fmt_pct(r, 3)}**  (check: NPV at IRR = {fmt_money(npv(r, cfs), cur)})"], {"irr": r}


def _dates(it, where, n):
    ds = it.get("dates")
    if not isinstance(ds, list) or len(ds) != n:
        raise FinError(f"{where}: 'dates' must be a list with one date per cash flow ({n}).")
    dates = [parse_date(x, f"{where} dates[{i}]") for i, x in enumerate(ds)]
    if any(d < dates[0] for d in dates):
        raise FinError(f"{where}: no date may be before the first date.")
    return dates


def op_xnpv(it, where, w, cur, ctx):
    r = rate(it.get("rate"), where + " rate", w)
    cfs = flows(it.get("cashflows"), where + " cashflows")
    dates = _dates(it, where, len(cfs))
    v = xnpv(r, cfs, dates)
    return "XNPV", [f"Inputs: rate {fmt_pct(r)}, {len(cfs)} dated cash flows from {dates[0]} to {dates[-1]}",
                    "Formula: XNPV = Σ CFᵢ / (1 + r)^((dᵢ - d₀) / 365)",
                    f"Result: **XNPV = {fmt_money(v, cur)}**"], {"xnpv": v}


def op_xirr(it, where, w, cur, ctx):
    cfs = flows(it.get("cashflows"), where + " cashflows")
    dates = _dates(it, where, len(cfs))
    r = xirr(cfs, dates, w, where)
    return "XIRR", [f"Inputs: {len(cfs)} dated cash flows from {dates[0]} to {dates[-1]}",
                    "Formula: find r where Σ CFᵢ / (1 + r)^((dᵢ - d₀) / 365) = 0",
                    f"Result: **XIRR = {fmt_pct(r, 3)}**"], {"xirr": r}


def op_payback(it, where, w, cur, ctx, discounted=False):
    cfs = flows(it.get("cashflows"), where + " cashflows")
    r = rate(it.get("rate"), where + " rate", w) if discounted else None
    p = payback(cfs, r)
    name = "Discounted payback" if discounted else "Payback"
    per = str(it.get("period") or "years")
    res = f"**{name} = {p:.2f} {per}**" if p is not None else f"**Not paid back** within the {len(cfs) - 1} {per} given."
    form = ("Formula: first t where Σ CFₜ / (1 + r)ᵗ turns positive, interpolated inside that period"
            if discounted else "Formula: first t where cumulative cash flow turns positive, interpolated inside that period")
    inp = f"Inputs: {'rate ' + fmt_pct(r) + ', ' if discounted else ''}cash flows {_flows_text(cfs, cur)}"
    return name, [inp, form, "Result: " + res], {"payback": p}


def _loan(it, where, w):
    P = num(it.get("principal") or it.get("amount") or it.get("loan"), where + " principal")
    if P <= 0:
        raise FinError(f"{where}: principal must be above zero.")
    ar = rate(it.get("annual_rate") if it.get("annual_rate") is not None else it.get("rate"), where + " annual_rate", w)
    ppy = int(num(it.get("periods_per_year", 12), where + " periods_per_year"))
    if ppy not in (1, 2, 4, 12, 24, 26, 52):
        raise FinError(f"{where}: periods_per_year must be 1, 2, 4, 12, 24, 26 or 52.")
    if it.get("months") is not None:
        n = int(round(num(it.get("months"), where + " months") * ppy / 12))
    elif it.get("years") is not None:
        n = int(round(num(it.get("years"), where + " years") * ppy))
    elif it.get("nper") is not None:
        n = int(num(it.get("nper"), where + " nper"))
    else:
        raise FinError(f"{where}: give 'years' or 'months'.")
    if n <= 0 or n > 1200:
        raise FinError(f"{where}: number of payments must be 1 to 1200.")
    return P, ar, ppy, n


def op_loan_payment(it, where, w, cur, ctx):
    P, ar, ppy, n = _loan(it, where, w)
    rp = ar / ppy
    p = pmt(P, rp, n)
    tot = p * n
    return "Loan payment", [f"Inputs: principal {fmt_money(P, cur)}, annual rate {fmt_pct(ar, 3)}, {n} payments ({ppy} per year)",
                            "Formula: PMT = P × i / (1 - (1 + i)^-n), i = annual rate / payments per year",
                            f"Result: **payment = {fmt_money(p, cur)}** per period. Total paid {fmt_money(tot, cur)}, total interest {fmt_money(tot - P, cur)}"], {"payment": p}


def op_amortization(it, where, w, cur, ctx):
    P, ar, ppy, n = _loan(it, where, w)
    rp = ar / ppy
    p = pmt(P, rp, n)
    extra = num(it.get("extra_payment", 0) or 0, where + " extra_payment")
    rows = amort_rows(P, rp, n, p, extra)
    start = parse_date(it["start_date"], where + " start_date") if it.get("start_date") else None
    tot_int = sum(r[2] for r in rows)
    tot_pay = sum(r[1] for r in rows)
    lines = [f"Inputs: principal {fmt_money(P, cur)}, annual rate {fmt_pct(ar, 3)}, {n} payments ({ppy} per year)"
             + (f", extra {fmt_money(extra, cur)} per payment" if extra else ""),
             "Formula: PMT = P × i / (1 - (1 + i)^-n); each row: interest = balance × i, principal = payment - interest",
             f"Result: **payment = {fmt_money(p, cur)}**, {len(rows)} payments, total interest {fmt_money(tot_int, cur)}, total paid {fmt_money(tot_pay, cur)}"]
    head = rows[:3] + ([None] if len(rows) > 6 else []) + (rows[-3:] if len(rows) > 6 else rows[3:6])
    tbl = []
    for r in head:
        if r is None:
            tbl.append("...")
        else:
            tbl.append(f"#{r[0]}: payment {fmt_money(r[1], cur)}, interest {fmt_money(r[2], cur)}, "
                       f"principal {fmt_money(r[3], cur)}, balance {fmt_money(r[4], cur)}")
    tbl.append("Full table: the .xlsx file below.")
    ctx["tables"].append(dict(kind="amortization", P=P, ar=ar, ppy=ppy, n=n, payment=p, extra=extra, rows=rows, start=start,
                              cur=cur, title=it.get("title") or "Loan amortization"))
    return "Amortization", lines + tbl, {"payment": p, "periods": len(rows), "total_interest": tot_int}


def op_cagr(it, where, w, cur, ctx):
    a = num(it.get("start_value") if it.get("start_value") is not None else it.get("start"), where + " start_value")
    b = num(it.get("end_value") if it.get("end_value") is not None else it.get("end"), where + " end_value")
    y = num(it.get("years"), where + " years")
    if a <= 0 or b <= 0 or y <= 0:
        raise FinError(f"{where}: start, end and years must be above zero.")
    r = (b / a) ** (1.0 / y) - 1.0
    return "CAGR", [f"Inputs: start {fmt_money(a, cur)}, end {fmt_money(b, cur)}, {fmt_num(y, 2)} years",
                    "Formula: CAGR = (end / start)^(1 / years) - 1",
                    f"Result: **CAGR = {fmt_pct(r, 3)}**"], {"cagr": r}


def _when(it):
    return 1 if str(it.get("when") or "end").lower() in ("begin", "start", "beginning", "1") else 0


def op_fv(it, where, w, cur, ctx):
    r = rate(it.get("rate"), where + " rate", w, allow_neg=True)
    n = num(it.get("nper") if it.get("nper") is not None else it.get("years"), where + " nper")
    pv = num(it.get("pv", 0) or 0, where + " pv")
    pm = num(it.get("pmt", 0) or 0, where + " pmt")
    b = _when(it)
    g = (1 + r) ** n
    ann = (pm * ((g - 1) / r) * ((1 + r) if b else 1)) if r != 0 else pm * n
    v = pv * g + ann
    return "Future value", [f"Inputs: rate {fmt_pct(r)} per period, {fmt_num(n, 2)} periods, present value {fmt_money(pv, cur)}, payment {fmt_money(pm, cur)} at {'start' if b else 'end'} of each period",
                            "Formula: FV = PV × (1 + r)ⁿ + PMT × ((1 + r)ⁿ - 1) / r" + (" × (1 + r)" if b else ""),
                            f"Result: **FV = {fmt_money(v, cur)}**  (all amounts positive; Excel FV shows the opposite sign)"], {"fv": v}


def op_pv(it, where, w, cur, ctx):
    r = rate(it.get("rate"), where + " rate", w, allow_neg=True)
    n = num(it.get("nper") if it.get("nper") is not None else it.get("years"), where + " nper")
    fv = num(it.get("fv", 0) or 0, where + " fv")
    pm = num(it.get("pmt", 0) or 0, where + " pmt")
    b = _when(it)
    g = (1 + r) ** n
    ann = (pm * (1 - 1 / g) / r * ((1 + r) if b else 1)) if r != 0 else pm * n
    v = fv / g + ann
    return "Present value", [f"Inputs: rate {fmt_pct(r)} per period, {fmt_num(n, 2)} periods, future value {fmt_money(fv, cur)}, payment {fmt_money(pm, cur)} at {'start' if b else 'end'} of each period",
                             "Formula: PV = FV / (1 + r)ⁿ + PMT × (1 - (1 + r)^-n) / r" + (" × (1 + r)" if b else ""),
                             f"Result: **PV = {fmt_money(v, cur)}**  (all amounts positive; Excel PV shows the opposite sign)"], {"pv": v}


def op_wacc(it, where, w, cur, ctx):
    E = num(it.get("equity"), where + " equity")
    D = num(it.get("debt"), where + " debt")
    re_ = rate(it.get("cost_of_equity"), where + " cost_of_equity", w)
    rd = rate(it.get("cost_of_debt"), where + " cost_of_debt", w)
    t = rate(it.get("tax_rate", 0) or 0, where + " tax_rate", w)
    if E < 0 or D < 0 or E + D <= 0:
        raise FinError(f"{where}: equity and debt must be zero or more, and not both zero.")
    V = E + D
    v = E / V * re_ + D / V * rd * (1 - t)
    return "WACC", [f"Inputs: equity {fmt_money(E, cur)}, debt {fmt_money(D, cur)}, cost of equity {fmt_pct(re_)}, cost of debt {fmt_pct(rd)}, tax rate {fmt_pct(t)}",
                    "Formula: WACC = E/V × Re + D/V × Rd × (1 - T), V = E + D",
                    f"= {E / V:.4f} × {fmt_pct(re_)} + {D / V:.4f} × {fmt_pct(rd)} × {1 - t:.4f}",
                    f"Result: **WACC = {fmt_pct(v, 3)}**"], {"wacc": v}


def op_break_even(it, where, w, cur, ctx):
    F = num(it.get("fixed_costs") if it.get("fixed_costs") is not None else it.get("fixed"), where + " fixed_costs")
    p = num(it.get("price"), where + " price")
    vc = num(it.get("variable_cost"), where + " variable_cost")
    if p <= vc:
        raise FinError(f"{where}: price must be above variable cost per unit, or there is no break-even.")
    u = F / (p - vc)
    return "Break-even", [f"Inputs: fixed costs {fmt_money(F, cur)}, price {fmt_money(p, cur)} per unit, variable cost {fmt_money(vc, cur)} per unit",
                          "Formula: units = fixed costs / (price - variable cost); revenue = units × price",
                          f"Contribution margin = {fmt_money(p - vc, cur)} per unit ({fmt_pct((p - vc) / p)})",
                          f"Result: **{fmt_num(u, 1)} units** (round up to {math.ceil(u - 1e-9):,}), revenue {fmt_money(u * p, cur)}"], {"units": u}


def op_dcf(it, where, w, cur, ctx):
    cfs = flows(it.get("cashflows"), where + " cashflows")
    r = rate(it.get("rate") if it.get("rate") is not None else it.get("discount_rate"), where + " rate", w)
    g = it.get("terminal_growth")
    mult = it.get("terminal_multiple")
    tv = 0.0
    tv_text = "no terminal value"
    if g is not None:
        g = rate(g, where + " terminal_growth", w, allow_neg=True)
        if g >= r:
            raise FinError(f"{where}: terminal growth must be below the discount rate.")
        tv = cfs[-1] * (1 + g) / (r - g)
        tv_text = f"TV = CFₙ × (1 + g) / (r - g) = {fmt_money(cfs[-1], cur)} × {1 + g:.4f} / ({fmt_pct(r)} - {fmt_pct(g)}) = {fmt_money(tv, cur)}"
    elif mult is not None:
        mult = num(mult, where + " terminal_multiple")
        tv = cfs[-1] * mult
        tv_text = f"TV = CFₙ × multiple = {fmt_money(cfs[-1], cur)} × {fmt_num(mult, 2)} = {fmt_money(tv, cur)}"
    n = len(cfs)
    pvs = [cf / (1 + r) ** (t + 1) for t, cf in enumerate(cfs)]
    pv_tv = tv / (1 + r) ** n
    ev = sum(pvs) + pv_tv
    nd = num(it.get("net_debt", 0) or 0, where + " net_debt")
    eq = ev - nd
    sh = it.get("shares")
    lines = [f"Inputs: {n} years of cash flow ({_flows_text(cfs, cur, 1)}), discount rate {fmt_pct(r)}"
             + (f", net debt {fmt_money(nd, cur)}" if nd else ""),
             "Formula: EV = Σ CFₜ / (1 + r)ᵗ + TV / (1 + r)ⁿ",
             tv_text,
             f"PV of cash flows {fmt_money(sum(pvs), cur)}, PV of TV {fmt_money(pv_tv, cur)}"
             + (f" ({pv_tv / ev * 100:.1f}% of EV)" if ev else ""),
             f"Result: **enterprise value = {fmt_money(ev, cur)}**" + (f", equity value = {fmt_money(eq, cur)}" if nd else "")]
    if sh:
        s = num(sh, where + " shares")
        if s > 0:
            lines.append(f"Per share: {fmt_money(eq, cur)} / {fmt_num(s, 0)} = **{fmt_money(eq / s, cur)}**")
    ctx["tables"].append(dict(kind="dcf", cfs=cfs, r=r, g=g if isinstance(g, float) else None,
                              mult=mult if isinstance(mult, float) else None, nd=nd, shares=num(sh, "shares") if sh else None,
                              cur=cur, title=it.get("title") or "DCF"))
    return "Simple DCF", lines, {"ev": ev, "equity": eq}


OPS = {"npv": op_npv, "irr": op_irr, "xnpv": op_xnpv, "xirr": op_xirr, "payback": op_payback,
       "discounted_payback": lambda *a: op_payback(*a, discounted=True), "loan_payment": op_loan_payment,
       "amortization": op_amortization, "cagr": op_cagr, "fv": op_fv, "pv": op_pv, "wacc": op_wacc,
       "break_even": op_break_even, "dcf": op_dcf}
ALIASES = {"pmt": "loan_payment", "payment": "loan_payment", "loan": "loan_payment", "amortisation": "amortization",
           "amortization_table": "amortization", "schedule": "amortization", "breakeven": "break_even",
           "discounted_payback_period": "discounted_payback", "payback_period": "payback", "future_value": "fv",
           "present_value": "pv"}


def check(spec, ctx):
    if not isinstance(spec, dict):
        ctx.err("Spec must be a JSON object with 'items'.")
        return {}
    items = spec.get("items")
    if items is None and spec.get("op"):
        items = [spec]
    if not isinstance(items, list) or not items:
        ctx.err("'items' must be a non-empty list of calculations.")
        return {}
    out = []
    for i, it in enumerate(items[:MAX_ITEMS]):
        where = f"items[{i}]"
        if not isinstance(it, dict):
            ctx.err(f"{where} must be an object.")
            continue
        op = ALIASES.get(str(it.get("op") or "").strip().lower(), str(it.get("op") or "").strip().lower())
        if op not in OPS:
            ctx.err(f"{where}: 'op' must be one of {', '.join(sorted(OPS))}.")
            continue
        if op in ("npv", "irr", "xnpv", "xirr", "payback", "discounted_payback", "dcf") and not isinstance(it.get("cashflows"), list):
            ctx.err(f"{where}: '{op}' needs 'cashflows' as a list of numbers.")
            continue
        d = dict(it)
        d["op"] = op
        out.append(d)
    if len(items) > MAX_ITEMS:
        ctx.warn(f"Only the first {MAX_ITEMS} calculations are done.")
    cur = str(spec.get("currency") or "")
    if cur.upper() in ("USD", "US$"):
        cur = "$"
    cur = cur[:3]
    return {"items": out, "title": str(spec.get("title") or "")[:120], "currency": cur, "chart": bool(spec.get("chart"))}


def compute(norm):
    blocks, results, warnings, errors = [], [], [], []
    ctx = {"tables": []}
    cur = norm.get("currency", "")
    for i, it in enumerate(norm["items"]):
        where = f"items[{i}]"
        w = []
        try:
            title, lines, vals = OPS[it["op"]](it, where, w, cur, ctx)
            label = it.get("label")
            body = []
            for ln in lines:
                body.append(f"- {ln}")
            blocks.append(f"**{title}**" + (f"  ({label})" if label else "") + "\n" + "\n".join(body))
            results.append({"op": it["op"], **vals})
        except FinError as e:
            errors.append(str(e))
            blocks.append(f"**{it['op']}**\n- Not computed: {e}")
        except (OverflowError, ZeroDivisionError, ValueError) as e:
            errors.append(f"{where}: {e}")
            blocks.append(f"**{it['op']}**\n- Not computed: {e}")
        warnings.extend(x for x in w if x not in warnings)
    text = "\n\n".join(blocks)
    if warnings:
        text += "\n\n_Notes: " + " ".join(warnings) + "_"
    text += "\n\n_Computed by IOTA /fin. No model arithmetic._"
    return {"text": text, "results": results, "warnings": warnings, "errors": errors, "tables": ctx["tables"]}


# ---------- workbooks ----------
def _xl_formats(wb):
    hdr = wb.add_format({"bold": True, "font_color": "#E0E0E0", "bg_color": "#141414", "border": 1, "border_color": "#606060", "align": "center"})
    money = wb.add_format({"num_format": "#,##0.00"})
    money_b = wb.add_format({"num_format": "#,##0.00", "bold": True, "top": 1})
    pct = wb.add_format({"num_format": "0.000%"})
    date = wb.add_format({"num_format": "yyyy-mm-dd"})
    bold = wb.add_format({"bold": True})
    title = wb.add_format({"bold": True, "font_size": 14})
    note = wb.add_format({"font_color": "#606060", "italic": True})
    num0 = wb.add_format({"num_format": "0"})
    return dict(hdr=hdr, money=money, money_b=money_b, pct=pct, date=date, bold=bold, title=title, note=note, num0=num0)


def write_amortization_xlsx(t, path, chart_png=None):
    import xlsxwriter
    wb = xlsxwriter.Workbook(str(path))
    F = _xl_formats(wb)
    ws = wb.add_worksheet("Amortization")
    ws.write(0, 0, t["title"], F["title"])
    ws.write(1, 0, "Inputs are in B4:B8. Change them and the schedule recalculates (rows are fixed to the original term).", F["note"])
    ins = [("Principal", t["P"], F["money"]), ("Annual rate", t["ar"], F["pct"]), ("Payments per year", t["ppy"], F["num0"]),
           ("Number of payments", t["n"], F["num0"]), ("Extra per payment", t["extra"], F["money"])]
    for k, (lab, v, f) in enumerate(ins):
        ws.write(3 + k, 0, lab, F["bold"])
        ws.write(3 + k, 1, v, f)
    ws.write(8, 0, "Payment", F["bold"])
    ws.write_formula(8, 1, "=PMT(B5/B6,B7,-B4)", F["money_b"], round(t["payment"], 2))
    hdr_row = 10
    cols = ["#", "Date", "Payment", "Interest", "Principal", "Balance"] if t["start"] else ["#", "Payment", "Interest", "Principal", "Balance"]
    for c, h in enumerate(cols):
        ws.write(hdr_row, c, h, F["hdr"])
    off = 1 if t["start"] else 0
    from xlsxwriter.utility import xl_rowcol_to_cell as rc
    for i, (k, pay, interest, princ, bal) in enumerate(t["rows"]):
        r = hdr_row + 1 + i
        ws.write_number(r, 0, k, F["num0"])
        if t["start"]:
            months = int(round(12 / t["ppy"])) if t["ppy"] <= 12 else 0
            d = add_months(t["start"], months * (k - 1)) if months else t["start"] + dt.timedelta(days=int(round(365 / t["ppy"] * (k - 1))))
            ws.write_datetime(r, 1, dt.datetime(d.year, d.month, d.day), F["date"])
        prev_bal = "$B$4" if i == 0 else rc(r - 1, 4 + off)
        c_pay, c_int, c_pr, c_bal = 1 + off, 2 + off, 3 + off, 4 + off
        ws.write_formula(r, c_int, f"=ROUND({prev_bal}*$B$5/$B$6,10)", F["money"], interest)
        ws.write_formula(r, c_pr, f"=MIN($B$9-{rc(r, c_int)}+$B$8,{prev_bal})", F["money"], princ)
        ws.write_formula(r, c_pay, f"={rc(r, c_int)}+{rc(r, c_pr)}", F["money"], pay)
        ws.write_formula(r, c_bal, f"={prev_bal}-{rc(r, c_pr)}", F["money"], bal)
    last = hdr_row + len(t["rows"])
    tr = last + 1
    ws.write(tr, 0, "Total", F["bold"])
    for c in (1 + off, 2 + off, 3 + off):
        ws.write_formula(tr, c, f"=SUM({rc(hdr_row + 1, c)}:{rc(last, c)})", F["money_b"],
                         sum(x[c - off] for x in t["rows"]))
    ws.set_column(0, 0, 20)
    ws.set_column(1, 6, 14)
    ws.freeze_panes(hdr_row + 1, 0)
    if chart_png:
        cs = wb.add_worksheet("Chart")
        cs.insert_image(1, 1, str(chart_png), {"x_scale": 0.75, "y_scale": 0.75})
    wb.close()


def write_dcf_xlsx(t, path, chart_png=None):
    import xlsxwriter
    from xlsxwriter.utility import xl_rowcol_to_cell as rc
    wb = xlsxwriter.Workbook(str(path))
    F = _xl_formats(wb)
    ws = wb.add_worksheet("DCF")
    ws.write(0, 0, t["title"], F["title"])
    ws.write(1, 0, "Inputs are in column B. Formulas recalculate.", F["note"])
    ws.write(3, 0, "Discount rate", F["bold"]); ws.write(3, 1, t["r"], F["pct"])
    ws.write(4, 0, "Terminal growth", F["bold"])
    if t["g"] is not None:
        ws.write(4, 1, t["g"], F["pct"])
    ws.write(5, 0, "Terminal multiple", F["bold"])
    if t["mult"] is not None:
        ws.write(5, 1, t["mult"])
    ws.write(6, 0, "Net debt", F["bold"]); ws.write(6, 1, t["nd"], F["money"])
    ws.write(7, 0, "Shares", F["bold"])
    if t["shares"]:
        ws.write(7, 1, t["shares"], F["num0"])
    h = 9
    for c, name in enumerate(["Year", "Cash flow", "Discount factor", "Present value"]):
        ws.write(h, c, name, F["hdr"])
    cfs, r = t["cfs"], t["r"]
    for i, cf in enumerate(cfs):
        row = h + 1 + i
        ws.write_number(row, 0, i + 1, F["num0"])
        ws.write_number(row, 1, cf, F["money"])
        ws.write_formula(row, 2, f"=1/(1+$B$4)^{rc(row, 0)}", wb.add_format({"num_format": "0.000000"}), 1 / (1 + r) ** (i + 1))
        ws.write_formula(row, 3, f"={rc(row, 1)}*{rc(row, 2)}", F["money"], cf / (1 + r) ** (i + 1))
    last = h + len(cfs)
    n = len(cfs)
    lastcf = rc(last, 1)
    s = last + 2
    pv_sum = sum(cf / (1 + r) ** (i + 1) for i, cf in enumerate(cfs))
    if t["g"] is not None:
        tv = cfs[-1] * (1 + t["g"]) / (r - t["g"])
        tv_f = f"={lastcf}*(1+$B$5)/($B$4-$B$5)"
    elif t["mult"] is not None:
        tv = cfs[-1] * t["mult"]
        tv_f = f"={lastcf}*$B$6"
    else:
        tv, tv_f = 0.0, "=0"
    pv_tv = tv / (1 + r) ** n
    ev = pv_sum + pv_tv
    rows = [("Sum of PV", f"=SUM({rc(h + 1, 3)}:{rc(last, 3)})", pv_sum),
            ("Terminal value", tv_f, tv),
            ("PV of terminal value", f"={rc(s + 1, 1)}/(1+$B$4)^{n}", pv_tv),
            ("Enterprise value", f"={rc(s, 1)}+{rc(s + 2, 1)}", ev),
            ("Equity value", f"={rc(s + 3, 1)}-$B$7", ev - t["nd"])]
    for k, (lab, f, v) in enumerate(rows):
        ws.write(s + k, 0, lab, F["bold"])
        ws.write_formula(s + k, 1, f, F["money_b"] if lab in ("Enterprise value", "Equity value") else F["money"], v)
    if t["shares"]:
        ws.write(s + 5, 0, "Per share", F["bold"])
        ws.write_formula(s + 5, 1, f"={rc(s + 4, 1)}/$B$8", F["money_b"], (ev - t["nd"]) / t["shares"])
    ws.set_column(0, 0, 22)
    ws.set_column(1, 3, 16)
    if chart_png:
        cs = wb.add_worksheet("Chart")
        cs.insert_image(1, 1, str(chart_png), {"x_scale": 0.75, "y_scale": 0.75})
    wb.close()


def chart_png(t, path, style="charcoal"):
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    import iota_theme as T
    T.mpl_setup(style)
    import matplotlib.pyplot as plt
    r = T.roles(style)
    fig, ax = plt.subplots(figsize=(10, 5.6), dpi=120)
    if t["kind"] == "amortization":
        ks = [x[0] for x in t["rows"]]
        bal = [x[4] for x in t["rows"]]
        ci, cp = [], []
        a = b = 0.0
        for x in t["rows"]:
            a += x[2]; b += x[3]
            ci.append(a); cp.append(b)
        ax.plot(ks, bal, color=r["series"][0], linestyle="-", linewidth=2.2, label="Balance")
        ax.plot(ks, cp, color=r["series"][1], linestyle="--", linewidth=1.8, label="Principal paid")
        ax.plot(ks, ci, color=r["series"][2], linestyle="-.", linewidth=1.8, label="Interest paid")
        ax.set_xlabel("Payment number")
        ax.set_title(t["title"], loc="left", fontsize=16)
    else:
        yrs = list(range(1, len(t["cfs"]) + 1))
        pv = [cf / (1 + t["r"]) ** y for y, cf in zip(yrs, t["cfs"])]
        x = list(range(len(yrs)))
        ax.bar([i - 0.2 for i in x], t["cfs"], width=0.4, color=r["series"][0], label="Cash flow")
        ax.bar([i + 0.2 for i in x], pv, width=0.4, color=r["series"][2], label="Present value")
        ax.set_xticks(x, [f"Y{y}" for y in yrs])
        ax.set_title(t["title"], loc="left", fontsize=16)
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"{v:,.0f}"))
    ax.legend(loc="best", frameon=True)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    fig.tight_layout()
    mark = T.mark_path(style)
    if mark.exists():
        try:
            from PIL import Image
            im = Image.open(mark)
            fig.figimage(im.resize((28, int(28 * im.height / im.width))), xo=fig.bbox.xmax - 44, yo=fig.bbox.ymax - 44, zorder=10)
        except Exception:  # noqa: BLE001
            pass
    fig.savefig(str(path), facecolor=r["field"])
    plt.close(fig)
