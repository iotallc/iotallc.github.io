"""/units: deterministic unit conversion and small engineering calcs.

The model only turns the request into a spec. Every number here comes from pint
and plain Python. Output is markdown that shows the math.
"""
import math
import re

_UREG = None
MAX_ITEMS = 20
R_AIR = 287.053  # J/(kg K)
GAMMA = 1.4


def ureg():
    global _UREG
    if _UREG is None:
        import pint
        u = pint.UnitRegistry(autoconvert_offset_to_baseunit=False)
        for d in ("pph = pound / hour", "kgph = kilogram / hour", "gpm = gallon / minute",
                  "lpm = liter / minute", "cfm = foot ** 3 / minute", "rpm_ = revolution / minute"):
            try:
                u.define(d)
            except Exception:  # noqa: BLE001
                pass
        _UREG = u
    return _UREG


# ---------- unit text clean-up ----------
_SUBS = [
    (r"°\s*F\b", "degF"), (r"°\s*C\b", "degC"), (r"°\s*R\b", "degR"), (r"\bdeg\s*F\b", "degF"),
    (r"\bdeg\s*C\b", "degC"), (r"\bfahrenheit\b", "degF"), (r"\bcelsius\b", "degC"), (r"\bcentigrade\b", "degC"),
    (r"²", "^2"), (r"³", "^3"), (r"·", "*"),
    # torque, always force-pound in shop use
    (r"\b(?:in|inch|inches)[-*\s]?(?:lbf|lbs?|pounds?)\b", "(inch*force_pound)"),
    (r"\b(?:lbf|lbs?|pounds?)[-*\s]?(?:in|inch|inches)\b", "(inch*force_pound)"),
    (r"\b(?:ft|foot|feet)[-*\s]?(?:lbf|lbs?|pounds?)\b", "(foot*force_pound)"),
    (r"\b(?:lbf|lbs?|pounds?)[-*\s]?(?:ft|foot|feet)\b", "(foot*force_pound)"),
    (r"\bkN[-*\s]?m\b", "(kN*m)"), (r"\bN[-*\s]?m\b", "(N*m)"), (r"\bNm\b", "(N*m)"), (r"\bkgf[-*\s]?m\b", "(kgf*m)"),
    # flow
    (r"\b(?:PPH|pph|lbs?/hr|lbs?/h|lb/hr)\b", "pph"), (r"\b(?:kg/hr|kg/h|kgph)\b", "kgph"),
    (r"\bGPM\b", "gpm"), (r"\bLPM\b", "lpm"), (r"\bCFM\b", "cfm"),
    # speed
    (r"\b(?:KTAS|KIAS|KCAS|KEAS|kts|kt|knots)\b", "knot"), (r"\bfps\b", "ft/s"),
    # pressure
    (r"\b(?:in\.?\s?Hg|\"Hg|inches of mercury)\b", "inHg"), (r"\bpsi[ga]\b", "psi"), (r"\bPSI\b", "psi"),
    (r"\bKPa\b", "kPa"), (r"\bkpa\b", "kPa"), (r"\bMpa\b", "MPa"), (r"\bmpa\b", "MPa"), (r"\bmbar\b", "millibar"),
    (r"\bhPa\b", "hectopascal"),
    # force and mass
    (r"\blbs\b", "lb"), (r"\bkips?\b", "kip"),
    # power
    (r"\b(?:shp|bhp|HP)\b", "hp"),
    (r"\bRPM\b", "rpm"),
]
_SUBS = [(re.compile(a), b) for a, b in _SUBS]


def clean_unit(u):
    s = str(u or "").strip()
    for rx, rep in _SUBS:
        s = rx.sub(rep, s)
    return s


def pretty_unit(u):
    s = str(u or "").strip()
    s = s.replace("^2", "²").replace("^3", "³").replace("**2", "²").replace("**3", "³")
    s = re.sub(r"\bdeg\s*F\b", "°F", s)
    s = re.sub(r"\bdeg\s*C\b", "°C", s)
    s = re.sub(r"\bdeg\s*R\b", "°R", s)
    s = re.sub(r"\bknots?\b", "kt", s)
    return s


def per(a, b):
    a, b = pretty_unit(a), pretty_unit(b)
    a = f"({a})" if "/" in a else a
    b = f"({b})" if ("/" in b or "*" in b or " " in b) else b
    return f"{a}/{b}"


def fmt(x, sig=5):
    """About 5 significant figures, thousands separators, no trailing zeros."""
    if x is None:
        return "?"
    if isinstance(x, complex):
        x = x.real
    if x == 0:
        return "0"
    if math.isnan(x) or math.isinf(x):
        return str(x)
    ax = abs(x)
    if ax >= 1e12 or ax < 1e-4:
        return f"{x:.{sig - 1}e}"
    digits = sig - int(math.floor(math.log10(ax))) - 1
    s = f"{x:,.{max(digits, 0)}f}"
    if "." in s:
        s = s.rstrip("0").rstrip(".")
    return s


def fmt_factor(x):
    return fmt(x, 6)


# ---------- quantities ----------
class UnitsError(ValueError):
    pass


def _num(v, where):
    if isinstance(v, bool):
        raise UnitsError(f"{where}: needs a number.")
    if isinstance(v, (int, float)):
        return float(v)
    try:
        return float(str(v).replace(",", "").strip())
    except ValueError:
        raise UnitsError(f"{where}: '{v}' is not a number.") from None


def parse_unit(u, where):
    U = ureg()
    s = clean_unit(u)
    if not s:
        raise UnitsError(f"{where}: unit is missing.")
    try:
        return U.Unit(s) if re.fullmatch(r"[A-Za-z_]+", s) else U.parse_units(s)
    except Exception:  # noqa: BLE001
        try:
            q = U.parse_expression(s)
            if hasattr(q, "units"):
                return (1 * q).units if not hasattr(q, "magnitude") else q.units
        except Exception:  # noqa: BLE001
            pass
    raise UnitsError(f"{where}: unknown unit '{u}'.")


def parse_qty(v, where, default_unit=None):
    """'1200 lbf', {'value':1200,'unit':'lbf'}, or a bare number (with default_unit)."""
    U = ureg()
    if isinstance(v, dict):
        val = _num(v.get("value"), where)
        unit = v.get("unit") or default_unit
        if not unit:
            return U.Quantity(val, U.dimensionless)
        return U.Quantity(val, parse_unit(unit, where))
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        if default_unit:
            return U.Quantity(float(v), parse_unit(default_unit, where))
        return U.Quantity(float(v), U.dimensionless)
    s = str(v or "").strip()
    if not s:
        raise UnitsError(f"{where}: value is missing.")
    m = re.match(r"^\s*([-+]?[\d,]*\.?\d+(?:[eE][-+]?\d+)?)\s*(.*)$", s)
    if not m:
        raise UnitsError(f"{where}: '{s}' needs a number and a unit, for example '1200 lbf'.")
    val = float(m.group(1).replace(",", ""))
    unit = m.group(2).strip() or default_unit
    if not unit:
        return U.Quantity(val, U.dimensionless)
    return U.Quantity(val, parse_unit(unit, where))


def _swap_lb(q):
    """pound (mass) <-> force_pound. Returns a new quantity or None."""
    U = ureg()
    s = str(q.units)
    if "force_pound" in s:
        t = s.replace("force_pound", "pound")
    elif "pound" in s:
        t = re.sub(r"(?<![a-z_])pound", "force_pound", s)
    else:
        return None
    try:
        return U.Quantity(q.magnitude, U.parse_units(t))
    except Exception:  # noqa: BLE001
        return None


def to_unit(q, unit, where, warnings):
    U = ureg()
    target = parse_unit(unit, where)
    try:
        return q.to(target)
    except Exception as e:  # noqa: BLE001
        if "Dimensionality" in type(e).__name__ or "dimension" in str(e).lower():
            alt = _swap_lb(q)
            if alt is not None:
                try:
                    r = alt.to(target)
                    warnings.append(f"{where}: lb read as {'lbf (force)' if 'force' in str(alt.units) else 'lb (mass)'} to match {pretty_unit(unit)}.")
                    return r
                except Exception:  # noqa: BLE001
                    pass
            raise UnitsError(f"{where}: cannot convert {pretty_unit(str(q.units))} to {pretty_unit(unit)} "
                             f"({q.dimensionality} vs {U.Quantity(1, target).dimensionality}).") from None
        raise UnitsError(f"{where}: {e}") from None


def qtext(q, unit_label=None):
    lab = unit_label if unit_label else f"{q.units:~P}"
    lab = re.sub(r"\bkn\b", "kt", pretty_unit(lab))
    if lab in ("", "dimensionless"):
        return fmt(q.magnitude)
    return f"{fmt(q.magnitude)} {lab}"


def is_imperial(*qs):
    for q in qs:
        s = str(q.units)
        if any(k in s for k in ("inch", "foot", "pound", "mile", "knot", "gallon", "psi", "yard", "slug", "degree_Fahrenheit")):
            return True
    return False


# ---------- ISA ----------
def isa_temperature_k(h_m):
    if h_m < -610:
        raise UnitsError("Altitude below -610 m is outside the standard atmosphere table.")
    if h_m <= 11000:
        return 288.15 - 0.0065 * h_m
    if h_m <= 20000:
        return 216.65
    if h_m <= 32000:
        return 216.65 + 0.001 * (h_m - 20000)
    raise UnitsError("Altitude above 32 km is outside the table used here.")


def speed_of_sound(h_m):
    t = isa_temperature_k(h_m)
    return math.sqrt(GAMMA * R_AIR * t), t


# ---------- ops ----------
_TEMP = {"degree_Fahrenheit": "F", "degree_Celsius": "C", "kelvin": "K", "degree_Rankine": "R"}
_TEMP_FORMULA = {
    ("F", "C"): "(°F - 32) × 5/9", ("C", "F"): "°C × 9/5 + 32", ("C", "K"): "°C + 273.15",
    ("K", "C"): "K - 273.15", ("F", "K"): "(°F - 32) × 5/9 + 273.15", ("K", "F"): "(K - 273.15) × 9/5 + 32",
    ("F", "R"): "°F + 459.67", ("R", "F"): "°R - 459.67", ("K", "R"): "K × 9/5", ("R", "K"): "°R × 5/9",
    ("C", "R"): "(°C + 273.15) × 9/5", ("R", "C"): "°R × 5/9 - 273.15",
}
_DELTA = {"F": "delta_degF", "C": "delta_degC", "K": "kelvin", "R": "degR"}
_DSYM = {"F": "Δ°F", "C": "Δ°C", "K": "K", "R": "Δ°R"}


def _temp_key(unit_str):
    U = ureg()
    try:
        u = U.parse_units(clean_unit(unit_str))
    except Exception:  # noqa: BLE001
        return None
    return _TEMP.get(str(u))


def op_convert(it, where, w):
    U = ureg()
    tos = it.get("to")
    if isinstance(tos, str):
        tos = [tos]
    if not tos:
        raise UnitsError(f"{where}: 'to' is missing (target unit or list of units).")
    if "value" in it and "from" in it:
        val = _num(it.get("value"), where + " value")
        src = it.get("from")
    else:
        q0 = parse_qty(it.get("value") or it.get("quantity"), where)
        val, src = q0.magnitude, f"{q0.units}"
    delta = bool(it.get("delta"))
    lines = []
    results = []
    ksrc = _temp_key(src)
    for t in tos[:8]:
        kdst = _temp_key(t)
        if ksrc and kdst:
            if delta:
                q = U.Quantity(val, _DELTA[ksrc]).to(_DELTA[kdst])
                factor = U.Quantity(1, _DELTA[ksrc]).to(_DELTA[kdst]).magnitude
                lines.append(f"{fmt(val)} {_DSYM[ksrc]} × {fmt_factor(factor)} = **{fmt(q.magnitude)} {_DSYM[kdst]}** (temperature difference)")
            else:
                q = U.Quantity(val, U.parse_units(clean_unit(src))).to(U.parse_units(clean_unit(t)))
                f = _TEMP_FORMULA.get((ksrc, kdst), "")
                sym = {"F": "°F", "C": "°C", "K": "K", "R": "°R"}
                lines.append(f"{sym[kdst]} = {f}  →  {fmt(val)} {sym[ksrc]} = **{fmt(q.magnitude)} {sym[kdst]}**" if f
                             else f"**{fmt(q.magnitude)} {sym[kdst]}**")
            results.append(q.magnitude)
            continue
        q_in = U.Quantity(val, parse_unit(src, where))
        q = to_unit(q_in, t, where, w)
        try:
            factor = to_unit(U.Quantity(1.0, q_in.units), t, where, []).magnitude
        except UnitsError:
            factor = q.magnitude / val if val else None
        if factor is None or not math.isfinite(factor):
            lines.append(f"{fmt(val)} {pretty_unit(src)} = **{fmt(q.magnitude)} {pretty_unit(t)}**")
        else:
            lines.append(f"{fmt(val)} {pretty_unit(src)} × {fmt_factor(factor)} {per(t, src)} = **{fmt(q.magnitude)} {pretty_unit(t)}**")
        results.append(q.magnitude)
    title = f"{fmt(val)} {pretty_unit(src)}{' (difference)' if delta else ''} to {', '.join(pretty_unit(x) for x in tos[:8])}"
    return title, lines, results


def _out(q, it, where, w, default):
    t = it.get("to")
    if isinstance(t, list):
        t = t[0] if t else None
    if t:
        return to_unit(q, t, where, w), t
    if default:
        return to_unit(q, default, where, w), None
    return q.to_compact(), None


def op_area(it, where, w):
    shape = str(it.get("shape") or "rectangle").lower()
    if shape in ("circle", "round", "disk", "disc"):
        if it.get("diameter") is not None:
            d = parse_qty(it["diameter"], where + " diameter")
            q = math.pi * d ** 2 / 4
            expr = f"A = π × d² / 4 = π × ({qtext(d)})² / 4"
        else:
            r = parse_qty(it.get("radius"), where + " radius")
            q = math.pi * r ** 2
            expr = f"A = π × r² = π × ({qtext(r)})²"
        base = d if it.get("diameter") is not None else r
    elif shape in ("annulus", "ring", "tube"):
        do = parse_qty(it.get("outer_diameter"), where + " outer_diameter")
        di = parse_qty(it.get("inner_diameter"), where + " inner_diameter")
        q = math.pi * (do ** 2 - di.to(do.units) ** 2) / 4
        expr = f"A = π × (D² - d²) / 4 = π × (({qtext(do)})² - ({qtext(di)})²) / 4"
        base = do
    elif shape == "triangle":
        b = parse_qty(it.get("base"), where + " base")
        h = parse_qty(it.get("height"), where + " height")
        q = 0.5 * b * h
        expr = f"A = b × h / 2 = {qtext(b)} × {qtext(h)} / 2"
        base = b
    else:
        L = parse_qty(it.get("length"), where + " length")
        W = parse_qty(it.get("width"), where + " width")
        q = L * W
        expr = f"A = L × W = {qtext(L)} × {qtext(W)}"
        base = L
    default = f"{base.units}**2"
    r, t = _out(q, it, where, w, default)
    return f"Area ({shape})", [f"{expr} = **{qtext(r, t)}**"], [r.magnitude]


def op_volume(it, where, w):
    shape = str(it.get("shape") or "box").lower()
    if shape in ("cylinder", "tank", "pipe"):
        d = parse_qty(it.get("diameter"), where + " diameter")
        h = parse_qty(it.get("height") or it.get("length"), where + " height")
        q = math.pi * d ** 2 / 4 * h
        expr = f"V = π × d² / 4 × h = π × ({qtext(d)})² / 4 × {qtext(h)}"
        base = d
    elif shape == "sphere":
        d = parse_qty(it.get("diameter"), where + " diameter")
        q = math.pi * d ** 3 / 6
        expr = f"V = π × d³ / 6 = π × ({qtext(d)})³ / 6"
        base = d
    else:
        L = parse_qty(it.get("length"), where + " length")
        W = parse_qty(it.get("width"), where + " width")
        H = parse_qty(it.get("height"), where + " height")
        q = L * W * H
        expr = f"V = L × W × H = {qtext(L)} × {qtext(W)} × {qtext(H)}"
        base = L
    r, t = _out(q, it, where, w, f"{base.units}**3")
    return f"Volume ({shape})", [f"{expr} = **{qtext(r, t)}**"], [r.magnitude]


def _force(it, where):
    return parse_qty(it.get("force"), where + " force")


def op_stress(it, where, w, name="Stress", sym="σ"):
    F = _force(it, where)
    if it.get("area") is not None:
        A = parse_qty(it.get("area"), where + " area")
        atext = qtext(A)
    elif it.get("diameter") is not None:
        d = parse_qty(it.get("diameter"), where + " diameter")
        A = math.pi * d ** 2 / 4
        atext = f"(π × ({qtext(d)})² / 4)"
    else:
        raise UnitsError(f"{where}: 'area' (or 'diameter') is missing.")
    if "pound" in str(F.units) and "force" not in str(F.units):
        F = _swap_lb(F)
        w.append(f"{where}: lb read as lbf (force).")
    q = F / A
    default = "psi" if is_imperial(F, A) else ("MPa" if sym == "σ" else "kPa")
    r, t = _out(q, it, where, w, default)
    return name, [f"{sym} = F / A = {qtext(F)} / {atext} = **{qtext(r, t)}**"], [r.magnitude]


def op_torque(it, where, w):
    F = _force(it, where)
    arm = parse_qty(it.get("arm") or it.get("distance") or it.get("length"), where + " arm")
    if "pound" in str(F.units) and "force" not in str(F.units):
        F = _swap_lb(F)
        w.append(f"{where}: lb read as lbf (force).")
    q = F * arm
    r, t = _out(q, it, where, w, "foot*force_pound" if is_imperial(F, arm) else "N*m")
    return "Torque", [f"T = F × r = {qtext(F)} × {qtext(arm)} = **{qtext(r, t)}**"], [r.magnitude]


def op_power(it, where, w):
    U = ureg()
    if it.get("torque") is not None:
        T = parse_qty(it.get("torque"), where + " torque")
        rpm = _num(it.get("rpm"), where + " rpm")
        omega = U.Quantity(2 * math.pi * rpm / 60.0, "radian/second")
        q = (T * omega).to("watt")
        r, t = _out(q, it, where, w, "hp" if is_imperial(T) else "kW")
        lines = [f"P = T × ω,  ω = 2π × {fmt(rpm)} rpm / 60 = {fmt(omega.magnitude)} rad/s",
                 f"P = {qtext(T)} × {fmt(omega.magnitude)} rad/s = **{qtext(r, t)}**"]
    else:
        F = _force(it, where)
        v = parse_qty(it.get("speed") or it.get("velocity"), where + " speed")
        if "pound" in str(F.units) and "force" not in str(F.units):
            F = _swap_lb(F)
            w.append(f"{where}: lb read as lbf (force).")
        q = (F * v).to("watt")
        r, t = _out(q, it, where, w, "hp" if is_imperial(F, v) else "kW")
        lines = [f"P = F × v = {qtext(F)} × {qtext(v)} = **{qtext(r, t)}**"]
    return "Power", lines, [r.magnitude]


def op_density(it, where, w):
    m = parse_qty(it.get("mass"), where + " mass")
    V = parse_qty(it.get("volume"), where + " volume")
    q = m / V
    r, t = _out(q, it, where, w, "lb/ft**3" if is_imperial(m, V) else "kg/m**3")
    return "Density", [f"ρ = m / V = {qtext(m)} / {qtext(V)} = **{qtext(r, t)}**"], [r.magnitude]


def _alt_m(it, where):
    a = it.get("altitude")
    if a is None or a == "":
        return 0.0, "sea level"
    q = parse_qty(a, where + " altitude", default_unit="ft")
    return to_unit(q, "m", where, []).magnitude, qtext(q)


def op_mach(it, where, w):
    U = ureg()
    v = parse_qty(it.get("speed"), where + " speed", default_unit="knot")
    h, htxt = _alt_m(it, where)
    a, T = speed_of_sound(h)
    vms = to_unit(v, "m/s", where, w).magnitude
    m = vms / a
    a_kt = U.Quantity(a, "m/s").to("knot").magnitude
    w.append("Mach uses the ISA standard day and true airspeed.")
    lines = [f"ISA at {htxt}: T = {fmt(T)} K ({fmt(T - 273.15)} °C)",
             f"a = √(γ × R × T) = √(1.4 × 287.053 × {fmt(T)}) = {fmt(a)} m/s ({fmt(a_kt)} kt)",
             f"M = v / a = {fmt(vms)} m/s / {fmt(a)} m/s = **Mach {m:.3f}**"]
    return f"Mach at {htxt}", lines, [m]


def op_speed_from_mach(it, where, w):
    U = ureg()
    M = _num(it.get("mach"), where + " mach")
    h, htxt = _alt_m(it, where)
    a, T = speed_of_sound(h)
    q = U.Quantity(M * a, "m/s")
    r, t = _out(q, it, where, w, "knot")
    w.append("Mach uses the ISA standard day; the result is true airspeed.")
    lines = [f"ISA at {htxt}: T = {fmt(T)} K, a = √(1.4 × 287.053 × {fmt(T)}) = {fmt(a)} m/s",
             f"v = M × a = {fmt(M)} × {fmt(a)} m/s = **{qtext(r, t or 'kt')}**"]
    return f"Mach {fmt(M)} at {htxt}", lines, [r.magnitude]


def op_percent_change(it, where, w):
    old = _num(it.get("old"), where + " old")
    new = _num(it.get("new"), where + " new")
    if old == 0:
        raise UnitsError(f"{where}: 'old' is 0, so percent change is undefined.")
    pc = (new - old) / abs(old) * 100.0
    return "Percent change", [f"Δ% = (new - old) / |old| × 100 = ({fmt(new)} - {fmt(old)}) / {fmt(abs(old))} × 100 = **{'+' if pc > 0 else ''}{fmt(pc, 4)} %**"], [pc]


def op_expr(it, where, w):
    U = ureg()
    e = str(it.get("expr") or it.get("expression") or "").strip()
    if not e:
        raise UnitsError(f"{where}: 'expr' is missing.")
    if len(e) > 200 or re.search(r"[;_]{2}|__|import|lambda", e):
        raise UnitsError(f"{where}: expression not allowed.")
    try:
        q = U.parse_expression(clean_unit(e))
    except Exception as ex:  # noqa: BLE001
        raise UnitsError(f"{where}: could not read '{e}': {ex}") from None
    if not hasattr(q, "units"):
        q = U.Quantity(float(q), U.dimensionless)
    r, t = _out(q, it, where, w, None)
    return "Calculation", [f"{pretty_unit(e)} = **{qtext(r, t)}**"], [r.magnitude]


OPS = {"convert": op_convert, "area": op_area, "volume": op_volume, "stress": op_stress,
       "pressure": lambda it, wh, w: op_stress(it, wh, w, "Pressure", "p"), "torque": op_torque,
       "power": op_power, "density": op_density, "mach": op_mach, "speed_from_mach": op_speed_from_mach,
       "percent_change": op_percent_change, "expr": op_expr}
ALIASES = {"conversion": "convert", "mach_number": "mach", "tas_from_mach": "speed_from_mach",
           "percent": "percent_change", "pct_change": "percent_change", "expression": "expr", "calc": "expr"}


def check(spec, ctx):
    """Light shape check so the model gets one clear retry."""
    if not isinstance(spec, dict):
        ctx.err("Spec must be a JSON object with 'items'.")
        return {}
    items = spec.get("items")
    if items is None and spec.get("op"):
        items = [spec]
    if not isinstance(items, list) or not items:
        ctx.err("'items' must be a non-empty list of calculations.")
        return {}
    out = []
    for i, it in enumerate(items[:MAX_ITEMS]):
        where = f"items[{i}]"
        if not isinstance(it, dict):
            ctx.err(f"{where} must be an object.")
            continue
        op = str(it.get("op") or "").strip().lower()
        op = ALIASES.get(op, op)
        if op not in OPS:
            ctx.err(f"{where}: 'op' must be one of {', '.join(sorted(OPS))}.")
            continue
        d = dict(it)
        d["op"] = op
        out.append(d)
    if len(items) > MAX_ITEMS:
        ctx.warn(f"Only the first {MAX_ITEMS} calculations are done.")
    return {"items": out, "title": str(spec.get("title") or "")[:120]}


def compute(norm):
    """Returns dict(text, results, warnings, errors). Errors per item are reported, not fatal."""
    blocks, results, warnings, errors = [], [], [], []
    for i, it in enumerate(norm["items"]):
        where = f"items[{i}]"
        w = []
        try:
            title, lines, vals = OPS[it["op"]](it, where, w)
            note = it.get("note")
            blocks.append(f"**{title}**" + (f"  ({note})" if note else "") + "\n" + "\n".join(f"- {ln}" for ln in lines))
            results.append({"op": it["op"], "values": vals})
        except UnitsError as e:
            errors.append(str(e))
            blocks.append(f"**{it['op']}**\n- Not computed: {e}")
        except Exception as e:  # noqa: BLE001
            errors.append(f"{where}: {type(e).__name__}: {e}")
            blocks.append(f"**{it['op']}**\n- Not computed: {e}")
        for x in w:
            if x not in warnings:
                warnings.append(x)
    text = "\n\n".join(blocks)
    if warnings:
        text += "\n\n_Notes: " + " ".join(warnings) + "_"
    text += "\n\n_Computed by IOTA /units (pint). No model arithmetic._"
    return {"text": text, "results": results, "warnings": warnings, "errors": errors}
