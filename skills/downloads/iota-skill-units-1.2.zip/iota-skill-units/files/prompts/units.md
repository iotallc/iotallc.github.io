SKILL: units. This turn only, reply with ONE ```json block and nothing else. IOTA's Python does all the math from it. Do not calculate anything yourself and do not write code.

Schema:
{"items": [ ...one object per calculation, up to 20... ]}

Item types ("op"):
- convert: {"op": "convert", "value": 250, "from": "psi", "to": ["kPa", "bar"]}
  Temperature: "degF", "degC", "K", "degR". For a temperature DIFFERENCE (a rise, a delta, a spread) add "delta": true.
- stress or pressure: {"op": "stress", "force": "1200 lbf", "area": "0.25 in^2", "to": "psi"}  (or "diameter" instead of "area")
- area: {"op": "area", "shape": "rectangle|circle|annulus|triangle", "length", "width" | "diameter" | "outer_diameter", "inner_diameter" | "base", "height", "to"}
- volume: {"op": "volume", "shape": "box|cylinder|sphere", "length", "width", "height" | "diameter", "height", "to": "gal"}
- torque: {"op": "torque", "force": "50 lbf", "arm": "18 in", "to": "ft-lbf"}
- power: {"op": "power", "torque": "300 ft-lbf", "rpm": 2500, "to": "hp"}  or  {"op": "power", "force": "5000 lbf", "speed": "250 knots", "to": "kW"}
- density: {"op": "density", "mass": "10 lb", "volume": "2 ft^3", "to": "kg/m^3"}
- mach: {"op": "mach", "speed": "450 knots", "altitude": "35000 ft"}   (standard atmosphere, true airspeed)
- speed_from_mach: {"op": "speed_from_mach", "mach": 0.78, "altitude": "35000 ft", "to": "knots"}
- percent_change: {"op": "percent_change", "old": 1200, "new": 1350}
- expr: {"op": "expr", "expr": "1200 lbf / (0.25 in^2)", "to": "psi"}   (only when nothing above fits)

Quantities are text with a number and a unit, for example "1200 lbf", "0.25 in^2", "45 in-lb", "1200 pph", "29.92 inHg".
Unit words that work: in, ft, mm, m, lb (mass), lbf, kgf, N, kN, psi, kPa, MPa, bar, inHg, in-lb, ft-lb, N-m, hp, kW, pph, kg/h, gpm, knots, mph, km/h, m/s, BTU, kJ, kWh, gal, L.

Rules: copy the user's numbers and units exactly. Leave "to" out if the user did not ask for a unit. Thrust is a force (lbf, kN). Fuel flow pph is pounds per hour.

Example:
```json
{"items": [{"op": "convert", "value": 250, "from": "psi", "to": ["kPa", "bar"]}, {"op": "mach", "speed": "450 knots", "altitude": "35000 ft"}]}
```
