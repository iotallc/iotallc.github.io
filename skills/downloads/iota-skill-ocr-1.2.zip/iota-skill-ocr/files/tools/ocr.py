"""/ocr: offline text from images and scanned PDFs.

RapidOCR (ONNX, CPU). PDF pages that already have a text layer are read directly
(pdfplumber); other pages are rendered with pypdfium2 and run through OCR.
Optional searchable PDF: page images with an invisible text layer (reportlab).
"""
import re
import statistics
import time
from pathlib import Path

IMAGE_EXT = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp", ".gif"}
PDF_EXT = {".pdf"}
MAX_PAGES = 300
MAX_SIDE = 4000
DPI = 220

_ENGINE = None


def kit_models_dir():
    return Path(__file__).resolve().parents[3] / "models" / "ocr"


def engine(lang="en"):
    """RapidOCR with the English recognizer when present (keeps spaces between words)."""
    global _ENGINE
    if _ENGINE is None:
        from rapidocr_onnxruntime import RapidOCR
        kw = {}
        rec = kit_models_dir() / "en_PP-OCRv3_rec_infer.onnx"
        if lang == "en" and rec.is_file():
            kw["rec_model_path"] = str(rec)
        _ENGINE = RapidOCR(**kw)
        _ENGINE._iota_model = "en_PP-OCRv3_rec" if kw else "default (ch_PP-OCRv4_rec)"
    return _ENGINE


_FIXES = [
    (re.compile(r"(?<=\d)\s?Ib(s|f)?\b"), lambda m: " lb" + (m.group(1) or "") if m.group(0).startswith(" ") else "lb" + (m.group(1) or "")),
    (re.compile(r"\b(in|ft)-Ib(s|f)?\b"), lambda m: m.group(1) + "-lb" + (m.group(2) or "")),
    (re.compile(r"\bIbf\b"), lambda m: "lbf"),
]


def fix_text(s):
    for rx, fn in _FIXES:
        s = rx.sub(fn, s)
    return s


def _box_metrics(box):
    xs = [p[0] for p in box]
    ys = [p[1] for p in box]
    return min(xs), min(ys), max(xs), max(ys)


def layout(results):
    """Group OCR boxes into lines and paragraphs. Returns (plain_text, lines) where each line
    is a list of cells (split at wide gaps) plus a paragraph-break flag."""
    items = []
    for r in results or []:
        try:
            box, text, score = r[0], str(r[1]), float(r[2])
        except Exception:  # noqa: BLE001
            continue
        if not text.strip():
            continue
        x0, y0, x1, y1 = _box_metrics(box)
        items.append(dict(x0=x0, y0=y0, x1=x1, y1=y1, h=max(1.0, y1 - y0), t=fix_text(text.strip()), s=score))
    if not items:
        return "", []
    items.sort(key=lambda d: (d["y0"] + d["y1"]) / 2)
    lines = []
    for it in items:
        cy = (it["y0"] + it["y1"]) / 2
        placed = False
        for ln in reversed(lines[-3:]):
            ov = min(ln["y1"], it["y1"]) - max(ln["y0"], it["y0"])
            if ov > 0.5 * min(ln["h"], it["h"]) or abs(cy - ln["cy"]) < 0.35 * ln["h"]:
                ln["items"].append(it)
                ln["y0"] = min(ln["y0"], it["y0"]); ln["y1"] = max(ln["y1"], it["y1"])
                placed = True
                break
        if not placed:
            lines.append(dict(items=[it], y0=it["y0"], y1=it["y1"], h=it["h"], cy=cy))
    med_h = statistics.median([ln["h"] for ln in lines]) if lines else 10
    out_lines = []
    prev_y1 = None
    for ln in lines:
        its = sorted(ln["items"], key=lambda d: d["x0"])
        cells = [its[0]["t"]]
        xs = [its[0]["x0"]]
        xe = [its[0]["x1"]]
        for a, b in zip(its, its[1:]):
            cw = max(2.0, (a["x1"] - a["x0"]) / max(1, len(a["t"])))
            gap = b["x0"] - a["x1"]
            if gap > 1.5 * cw:
                cells.append(b["t"])
                xs.append(b["x0"])
                xe.append(b["x1"])
            else:
                cells[-1] = cells[-1] + " " + b["t"]
                xe[-1] = b["x1"]
        para = prev_y1 is not None and (ln["y0"] - prev_y1) > 1.0 * med_h
        out_lines.append(dict(cells=cells, xs=xs, xe=xe, para=para, x0=its[0]["x0"], h=ln["h"]))
        prev_y1 = ln["y1"]
    txt = []
    for ln in out_lines:
        if ln["para"] and txt:
            txt.append("")
        txt.append("    ".join(ln["cells"]))
    return "\n".join(txt), out_lines


def _table_rows(run):
    """Align cells of a run of lines to column anchors taken from the widest row."""
    widest = max(run, key=lambda ln: len(ln["cells"]))
    anchors = widest["xs"]
    tol = 0.8 * max(ln["h"] for ln in run)
    rows = []

    def col_of(x):
        k = 0
        for j, ax in enumerate(anchors):
            if x + tol >= ax:
                k = j
        return k

    for ln in run:
        row = [""] * len(anchors)
        xs = ln.get("xs") or [0] * len(ln["cells"])
        xe = ln.get("xe") or [None] * len(ln["cells"])
        for t, x, x1 in zip(ln["cells"], xs, xe):
            k = col_of(x)
            # One OCR box can cover two columns (for example a header "Part number Description").
            # Place each word by its estimated start, assuming even character width in the box.
            if x1 is not None and len(t) > 1 and col_of(x1 - tol) > k:
                cw = (x1 - x) / len(t)
                pos = 0
                for w in t.split(" "):
                    if w:
                        kk = max(k, col_of(x + pos * cw))
                        row[kk] = (row[kk] + " " + w).strip()
                    pos += len(w) + 1
            else:
                row[k] = (row[k] + " " + t).strip()
        rows.append(row)
    return rows


def lines_to_md(lines):
    """Paragraph lines. Runs of 2+ consecutive lines with 2+ columns become a markdown table (best effort)."""
    out = []
    i = 0
    n = len(lines)
    while i < n:
        if len(lines[i]["cells"]) >= 2:
            j = i
            while j + 1 < n and len(lines[j + 1]["cells"]) >= 2 and not lines[j + 1]["para"]:
                j += 1
            if j > i:
                if out and out[-1] != "":
                    out.append("")
                rows = _table_rows(lines[i:j + 1])
                c = len(rows[0])
                esc = lambda s: s.replace("|", "\\|")  # noqa: E731
                out.append("| " + " | ".join(esc(x) for x in rows[0]) + " |")
                out.append("|" + "---|" * c)
                for r in rows[1:]:
                    out.append("| " + " | ".join(esc(x) for x in r) + " |")
                out.append("")
                i = j + 1
                continue
        if lines[i]["para"] and out and out[-1] != "":
            out.append("")
        out.append("  ".join(lines[i]["cells"]))
        i += 1
    return "\n".join(out).strip()


def _prep_image(im):
    from PIL import ImageOps
    try:
        im = ImageOps.exif_transpose(im)
    except Exception:  # noqa: BLE001
        pass
    if im.mode not in ("RGB", "L"):
        bg = None
        if im.mode in ("RGBA", "LA", "P"):
            from PIL import Image
            im = im.convert("RGBA")
            bg = Image.new("RGB", im.size, (255, 255, 255))
            bg.paste(im, mask=im.split()[-1])
            im = bg
        else:
            im = im.convert("RGB")
    if im.mode == "L":
        im = im.convert("RGB")
    scale = 1.0
    if max(im.size) > MAX_SIDE:
        scale = MAX_SIDE / max(im.size)
        im = im.resize((int(im.width * scale), int(im.height * scale)))
    return im, scale


def ocr_image(im, eng):
    import numpy as np
    arr = np.asarray(im)[:, :, ::-1].copy()  # RGB -> BGR for RapidOCR
    res, _ = eng(arr)
    return res or []


def _pages_of(path, opts, progress, warnings):
    """Yield (label, kind, pil_image_or_None, text_or_None, results, page_size_pts, words)"""
    ext = path.suffix.lower()
    force = str(opts.get("force_ocr", "0")) in ("1", "true", "yes")
    dpi = int(opts.get("dpi", DPI) or DPI)
    if ext in PDF_EXT:
        import pdfplumber
        import pypdfium2 as pdfium
        doc = pdfium.PdfDocument(str(path))
        n = len(doc)
        if n > MAX_PAGES:
            warnings.append(f"{path.name}: only the first {MAX_PAGES} of {n} pages are read.")
        n = min(n, MAX_PAGES)
        try:
            plumb = pdfplumber.open(str(path))
        except Exception:  # noqa: BLE001
            plumb = None
        for i in range(n):
            progress(i, n, f"{path.name}: page {i + 1} of {n}")
            text, words = None, None
            w_pt, h_pt = doc[i].get_size()
            if plumb is not None and not force:
                try:
                    pg = plumb.pages[i]
                    t = pg.extract_text() or ""
                    if len(re.sub(r"\s", "", t)) >= 25:
                        text = t
                        words = pg.extract_words()
                except Exception:  # noqa: BLE001
                    text = None
            if text is not None:
                yield (f"Page {i + 1}", "text layer", None, text, None, (w_pt, h_pt), words, i, doc)
                continue
            im = doc[i].render(scale=dpi / 72.0).to_pil()
            yield (f"Page {i + 1}", "ocr", im, None, None, (w_pt, h_pt), None, i, doc)
        if plumb is not None:
            plumb.close()
    else:
        from PIL import Image
        im0 = Image.open(str(path))
        frames = getattr(im0, "n_frames", 1) or 1
        frames = min(frames, MAX_PAGES)
        for f in range(frames):
            progress(f, frames, f"{path.name}" + (f": frame {f + 1} of {frames}" if frames > 1 else ""))
            try:
                im0.seek(f)
            except EOFError:
                break
            im = im0.copy()
            dpi_img = 150.0
            try:
                d = im0.info.get("dpi")
                if d and d[0] and d[0] > 30:
                    dpi_img = float(d[0])
            except Exception:  # noqa: BLE001
                pass
            size_pt = (im.width * 72.0 / dpi_img, im.height * 72.0 / dpi_img)
            yield (f"Image {f + 1}" if frames > 1 else "Image", "ocr", im, None, None, size_pt, None, f, None)


def run(inputs, opts, out_dir, tmp_dir, progress):
    t0 = time.time()
    warnings = []
    files = []
    if not inputs:
        raise ValueError("No image or PDF given. Drop an image or PDF into the chat, then type /ocr.")
    paths = []
    for p in inputs:
        pp = Path(p)
        if not pp.is_file():
            raise ValueError(f"File not found: {p}")
        if pp.suffix.lower() not in IMAGE_EXT | PDF_EXT:
            raise ValueError(f"{pp.name}: /ocr reads png, jpg, bmp, tif, webp, gif or pdf.")
        paths.append(pp)
    searchable = str(opts.get("searchable", "0")) in ("1", "true", "yes")
    eng = None
    sections_txt, sections_md = [], []
    stats = dict(pages=0, ocr_pages=0, text_pages=0, boxes=0, conf=[])
    for path in paths:
        page_txt, page_md = [], []
        spdf_pages = []
        multi = None
        for (label, kind, im, text, _r, size_pt, words, idx, doc) in _pages_of(path, opts, lambda i, n, m: progress(i, n, m), warnings):
            stats["pages"] += 1
            if kind == "text layer":
                stats["text_pages"] += 1
                t = text.strip()
                md = t
                spdf_pages.append(dict(kind="text", size=size_pt, words=words, idx=idx, doc=doc))
            else:
                if eng is None:
                    progress(0, 1, "loading the OCR model")
                    eng = engine(str(opts.get("lang", "en")))
                im, scale = _prep_image(im)
                res = ocr_image(im, eng)
                stats["ocr_pages"] += 1
                stats["boxes"] += len(res)
                stats["conf"].extend(float(r[2]) for r in res)
                t, lines = layout(res)
                md = lines_to_md(lines)
                spdf_pages.append(dict(kind="ocr", size=size_pt, im=im, res=res, idx=idx))
            multi = label
            page_txt.append((label, t))
            page_md.append((label, md))
        many = len(page_txt) > 1
        head = path.name
        body_t = "\n\n".join((f"--- {lab} ---\n{t}" if many else t) for lab, t in page_txt)
        body_m = "\n\n".join((f"### {lab}\n\n{m}" if many else m) for lab, m in page_md)
        sections_txt.append((head, body_t))
        sections_md.append((head, body_m))
        if searchable:
            if not any(p["kind"] == "ocr" for p in spdf_pages):
                warnings.append(f"{path.name} already has a text layer on every page, so no searchable copy was made.")
            else:
                progress(1, 1, "writing the searchable PDF")
                out_dir.mkdir(parents=True, exist_ok=True)
                sp = _unique(out_dir, path.stem + "-searchable", ".pdf")
                write_searchable_pdf(spdf_pages, sp, DPI)
                files.append(str(sp))
    multi_files = len(sections_txt) > 1
    txt = "\n\n".join((f"=== {h} ===\n{b}" if multi_files else b) for h, b in sections_txt).strip()
    md = "\n\n".join(f"## {h}\n\n{b}" for h, b in sections_md).strip()
    md = f"# OCR text\n\n{md}\n"
    if not txt.strip():
        warnings.append("No text was found.")
    conf = stats["conf"]
    meta = dict(pages=stats["pages"], ocr_pages=stats["ocr_pages"], text_pages=stats["text_pages"],
                boxes=stats["boxes"], mean_conf=round(sum(conf) / len(conf), 3) if conf else None,
                model=getattr(eng, "_iota_model", "") if eng else "", ms=int((time.time() - t0) * 1000))
    tmp_dir.mkdir(parents=True, exist_ok=True)
    stem = time.strftime("%Y-%m-%d_%H%M") + "_" + _slug(paths[0].stem)
    t_path = _unique(tmp_dir, stem, ".txt")
    t_path.write_text(txt + "\n", encoding="utf-8")
    m_path = t_path.with_suffix(".md")
    m_path.write_text(md, encoding="utf-8")
    low = [c for c in conf if c < 0.6]
    if conf and len(low) > 0.25 * len(conf):
        warnings.append("Many words were read with low confidence. Check the text against the source.")
    return dict(text=txt, md_text=md, txt_file=str(t_path), md_file=str(m_path), save_stem=stem, files=files,
                warnings=warnings, meta=meta)


def _slug(s):
    return re.sub(r"[^A-Za-z0-9]+", "-", s).strip("-").lower()[:48] or "ocr"


def _unique(folder, stem, ext):
    p = folder / f"{stem}{ext}"
    n = 2
    while p.exists():
        p = folder / f"{stem}-{n}{ext}"
        n += 1
    return p


def write_searchable_pdf(pages, out_path, dpi):
    from reportlab.pdfgen import canvas
    from reportlab.lib.utils import ImageReader
    c = canvas.Canvas(str(out_path))
    font = "Helvetica"
    for p in pages:
        w, h = p["size"]
        c.setPageSize((w, h))
        if p["kind"] == "ocr":
            im = p["im"]
            c.drawImage(ImageReader(im), 0, 0, width=w, height=h)
            sx, sy = w / im.width, h / im.height
            for r in p["res"]:
                try:
                    x0, y0, x1, y1 = _box_metrics(r[0])
                    t = fix_text(str(r[1]))
                except Exception:  # noqa: BLE001
                    continue
                _invisible(c, font, t, x0 * sx, h - y1 * sy, (x1 - x0) * sx, (y1 - y0) * sy)
        else:
            page = p["doc"][p["idx"]]
            im = page.render(scale=dpi / 72.0).to_pil()
            c.drawImage(ImageReader(im), 0, 0, width=w, height=h)
            for wd in p["words"] or []:
                _invisible(c, font, str(wd.get("text", "")), float(wd["x0"]), h - float(wd["bottom"]),
                           float(wd["x1"]) - float(wd["x0"]), float(wd["bottom"]) - float(wd["top"]))
        c.showPage()
    c.save()


def _invisible(c, font, text, x, y, bw, bh):
    text = "".join(ch if ord(ch) < 256 else "?" for ch in text)
    if not text.strip() or bw <= 0 or bh <= 0:
        return
    size = max(1.0, bh * 0.8)
    sw = c.stringWidth(text, font, size)
    to = c.beginText()
    to.setTextRenderMode(3)
    to.setFont(font, size)
    to.setTextOrigin(x, y + bh * 0.15)
    if sw > 0:
        to.setHorizScale(100.0 * bw / sw)
    to.textOut(text)
    c.drawText(to)
