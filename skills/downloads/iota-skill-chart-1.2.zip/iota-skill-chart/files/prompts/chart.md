SKILL: chart. This turn only, reply with ONE ```json block and nothing else. IOTA draws the chart from it. Do not write code.

Schema:
{"type": "bar" | "line" | "pie" | "scatter",
 "title": "short plain title",
 "subtitle": "optional",
 "x_label": "optional, with units", "y_label": "optional, with units",
 "x": [categories or x values],                      (bar, line)
 "series": [{"name": "...", "values": [numbers]}],   (bar, line; 1 to 4 series, same length as x)
 "series": [{"name": "...", "x": [numbers], "y": [numbers]}],   (scatter; 1 to 4 series)
 "labels": ["..."], "values": [numbers],             (pie; up to 5 slices)
 "source": "optional note, for example where the numbers came from"}

If the user attached a CSV or XLSX, do not copy numbers. Use column names instead:
 "data": {"file": "<attached file path>", "x": "<column>", "y": ["<column>", ...]}
 (pie: "data": {"file": "...", "labels": "<column>", "values": "<column>"})

Rules: use only numbers the user gave or that appear in the attached data. Plain titles, no slogans. Pick bar for categories, line for values over time, scatter for two measured values, pie only for parts of a whole.

Example:
```json
{"type": "bar", "title": "Runtime by month", "x": ["Jan", "Feb", "Mar"], "series": [{"name": "Bench A", "values": [42, 51, 48]}], "y_label": "Runtime (h)"}
```
