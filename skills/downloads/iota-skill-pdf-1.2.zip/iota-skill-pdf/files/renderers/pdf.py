"""PDF renderer: validated pdf spec -> PDF. Styles: charcoal (default) or print (white pages, black text)."""
import os
import re
import tempfile
from pathlib import Path

from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.units import inch
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import (BaseDocTemplate, Frame, PageTemplate, Paragraph, Table, TableStyle, Image,
                                PageBreak, KeepTogether)
from xml.sax.saxutils import escape

import iota_theme as T
from renderers import chart as chart_r

NUM = re.compile(r"[-+]?[0-9][0-9.,]*%?")


def _p(text):
    return escape(T.clean(text)).replace("\n", "<br/>")


def render(spec, out_path, style=None):
    style = style or spec.get("style") or "charcoal"
    r = T.roles(style)
    C = {k: T.rl_color(v) for k, v in r.items() if isinstance(v, str) and v.startswith("#")}
    reg, bold = T.rl_fonts()
    PW, PH = A4 if spec.get("page_size") == "a4" else letter
    M = 0.75 * inch
    st = {
        "h1": ParagraphStyle("h1", fontName=bold, fontSize=24, leading=29, textColor=C["title"], spaceAfter=4),
        "sub": ParagraphStyle("sub", fontName=reg, fontSize=12, leading=16, textColor=C["body"], spaceAfter=14),
        "h2": ParagraphStyle("h2", fontName=bold, fontSize=15, leading=19, textColor=C["heading"], spaceBefore=12,
                             spaceAfter=6),
        "body": ParagraphStyle("body", fontName=reg, fontSize=10.5, leading=15, textColor=C["text"], spaceAfter=8),
        "cap": ParagraphStyle("cap", fontName=reg, fontSize=9, leading=12, textColor=C["muted"], spaceBefore=4,
                              spaceAfter=10),
        "bullet": ParagraphStyle("bullet", fontName=reg, fontSize=10.5, leading=15, textColor=C["text"],
                                 leftIndent=14, bulletIndent=2, spaceAfter=3, bulletColor=C["muted"],
                                 bulletFontSize=8),
    }
    title = spec["title"]
    mark = str(T.mark_path(style))

    def on_page(cv, doc):
        cv.saveState()
        cv.setFillColor(C["page"])
        cv.rect(0, 0, PW, PH, stroke=0, fill=1)
        if os.path.exists(mark):
            cv.drawImage(mark, PW - M - 0.32 * inch, PH - 0.62 * inch, 0.32 * inch, 0.32 * inch, mask="auto")
        cv.setFillColor(C["muted"])
        cv.setFont(reg, 8.5)
        cv.drawString(M, PH - 0.5 * inch, T.clean(title).upper()[:90])
        cv.setStrokeColor(C["rule"] if style == "print" else T.rl_color(T.BLACK))
        cv.setLineWidth(0.8)
        cv.line(M, 0.6 * inch, PW - M, 0.6 * inch)
        cv.drawString(M, 0.4 * inch, "IOTA  |  " + T.clean(title)[:90])
        cv.drawRightString(PW - M, 0.4 * inch, f"Page {doc.page}")
        cv.restoreState()

    def table(cols, rows, widths):
        n = len(cols)
        widths = widths or [1.0 / n] * n
        numeric = [bool(rows) and all(NUM.fullmatch(str(rw[i]).strip() or "x") for rw in rows) for i in range(n)]
        hs = [ParagraphStyle(f"h{i}", fontName=bold, fontSize=9.5, leading=12, textColor=C["header_text"],
                             alignment=2 if numeric[i] else 0) for i in range(n)]
        cs = [ParagraphStyle(f"c{i}", fontName=reg, fontSize=9.5, leading=12,
                             textColor=C["title"] if i == 0 else C["text"] if style == "print" else C["body"],
                             alignment=2 if numeric[i] else 0) for i in range(n)]
        data = [[Paragraph(_p(c), hs[i]) for i, c in enumerate(cols)]]
        data += [[Paragraph(_p(v), cs[i]) for i, v in enumerate(rw)] for rw in rows]
        t = Table(data, colWidths=[w * (PW - 2 * M) for w in widths], repeatRows=1)
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), C["header_fill"]),
            ("LINEBELOW", (0, 0), (-1, 0), 0.8, C["rule"]),
            ("LINEBELOW", (0, 1), (-1, -1), 0.5, C["faint"]),
            ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ("LEFTPADDING", (0, 0), (-1, -1), 8), ("RIGHTPADDING", (0, 0), (-1, -1), 8),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE")]))
        return t

    doc = BaseDocTemplate(str(out_path), pagesize=(PW, PH), leftMargin=M, rightMargin=M, topMargin=0.95 * inch,
                          bottomMargin=0.85 * inch, title=T.clean(title), author="IOTA")
    frame = Frame(M, 0.85 * inch, PW - 2 * M, PH - 1.8 * inch, id="f", leftPadding=0, rightPadding=0, topPadding=0,
                  bottomPadding=0)
    doc.addPageTemplates([PageTemplate("p", [frame], onPage=on_page)])
    story = [Paragraph(_p(title), st["h1"])]
    if spec.get("subtitle"):
        story.append(Paragraph(_p(spec["subtitle"]), st["sub"]))
    with tempfile.TemporaryDirectory(prefix="iota-pdf-") as tmp:
        for n, b in enumerate(spec["blocks"]):
            k = b["type"]
            if k == "heading":
                story.append(Paragraph(_p(b["text"]), st["h2"]))
            elif k == "text":
                story.append(Paragraph(_p(b["text"]), st["body"]))
            elif k == "bullets":
                story += [Paragraph(_p(x), st["bullet"], bulletText="\u25AA") for x in b["items"]]
            elif k == "table":
                story.append(table(b["columns"], b["rows"], b.get("col_widths")))
                if b.get("caption"):
                    story.append(Paragraph(_p(b["caption"]), st["cap"]))
            elif k == "chart":
                png = Path(tmp) / f"chart-{n}.png"
                chart_r.render(b["chart"], png, style, size=(10, 4.6), mark=False, field=r["page"], show_titles=False)
                w = PW - 2 * M
                parts = [Image(str(png), w, w * 4.6 / 10)]
                if b.get("caption"):
                    parts.append(Paragraph(_p(b["caption"]), st["cap"]))
                story.append(KeepTogether(parts))
            elif k == "page_break":
                story.append(PageBreak())
        doc.build(story)
    return out_path
