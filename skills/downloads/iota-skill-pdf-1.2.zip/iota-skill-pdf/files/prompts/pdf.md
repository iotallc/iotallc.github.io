SKILL: pdf. This turn only, reply with ONE ```json block and nothing else. IOTA builds the PDF report in the IOTA theme from it. Do not write code.

Schema:
{"title": "report title",
 "subtitle": "optional",
 "blocks": [ in reading order, each one of:
   {"type": "heading", "text": "1. Section name"},
   {"type": "text", "text": "a paragraph"},
   {"type": "bullets", "items": ["...", "..."]},
   {"type": "table", "columns": ["up to 8"], "rows": [["cell", ...]], "caption": "optional"},
   {"type": "chart", "chart": {chart object: type, x, series or labels/values, x_label, y_label}, "caption": "optional"},
   {"type": "page_break"}
 ]}

Rules: plain engineering language, no slogans. Use only facts and numbers from the conversation or attached files. Number the headings. Keep paragraphs short.

Example:
```json
{"title": "Bench test report", "blocks": [{"type": "heading", "text": "1. Summary"}, {"type": "text", "text": "Two benches ran for six months with no failures."}]}
```
